"""Create separate reproducible source archives for Connector and PGC website."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

BASE = Path(__file__).resolve().parents[3]
OUTPUT = BASE / "output"
OUTPUT.mkdir(exist_ok=True)
EXCLUDED = {"bin", "obj", "node_modules", "dist", "artifacts", ".git", ".next", "coverage", ".prisma", ".cache"}


def package(source: Path, target: Path, root_name: str, excluded_top_level: str | None = None) -> None:
    if not source.is_dir():
        raise FileNotFoundError(f"Source directory does not exist: {source}")
    files = [path for path in source.rglob("*")
             if path.is_file() and not any(part in EXCLUDED for part in path.relative_to(source).parts)
             and path.relative_to(source).parts[0] != excluded_top_level]
    with ZipFile(target, "w", compression=ZIP_DEFLATED, compresslevel=7) as archive:
        for path in sorted(files):
            archive.write(path, str(Path(root_name) / path.relative_to(source)))
    with ZipFile(target) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"Corrupt archive member: {bad}")
    print(f"{target.name}: {len(files)} files; {target.stat().st_size} bytes")


package(BASE / "work" / "pgc-connector", OUTPUT / "PGC-Connector-1.2.10-source.zip", "pgc-connector")
website = BASE / "work" / "pgc-standalone-v27-2026-09-18"
if website.is_dir():
    package(website, OUTPUT / "PGC-Website-v27-connector-safety-2026-09-23.zip", "pgc-website")
