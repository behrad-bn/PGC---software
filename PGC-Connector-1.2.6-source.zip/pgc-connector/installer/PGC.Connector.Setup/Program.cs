using System.Diagnostics;
using System.IO.Compression;
using System.Security.Principal;
using System.Windows.Forms;

namespace PGC.Connector.Setup;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Contains("--quiet", StringComparer.Ordinal))
        {
            try { SetupWindow.Install(); return 0; }
            catch { return 1; }
        }
        ApplicationConfiguration.Initialize();
        Application.Run(new SetupWindow());
        return 0;
    }
}

internal sealed class SetupWindow : Form
{
    private readonly PictureBox _logo = new()
    {
        Dock = DockStyle.Right, Width = 100, SizeMode = PictureBoxSizeMode.Zoom,
        Padding = new Padding(8)
    };
    private readonly Label _status = new()
    {
        Dock = DockStyle.Top, Height = 80, TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
        Text = "در حال آماده‌سازی نصب PGC Connector…"
    };
    private readonly Label _headline = new()
    {
        Dock = DockStyle.Top, Height = 54, TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
        Text = "PGC CONNECTOR", Font = new System.Drawing.Font("Segoe UI", 22, System.Drawing.FontStyle.Bold)
    };
    private readonly ProgressBar _progress = new() { Dock = DockStyle.Top, Height = 16, Style = ProgressBarStyle.Marquee };
    private readonly Button _close = new() { Dock = DockStyle.Bottom, Height = 42, Text = "بستن", Enabled = false };

    public SetupWindow()
    {
        Text = "نصب PGC Connector 1.2.6";
        ClientSize = new System.Drawing.Size(540, 230);
        MinimumSize = Size;
        MaximizeBox = false;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterScreen;
        RightToLeft = RightToLeft.Yes;
        BackColor = System.Drawing.Color.FromArgb(18, 20, 25);
        ForeColor = System.Drawing.Color.White;
        _status.ForeColor = System.Drawing.Color.White;
        _headline.ForeColor = System.Drawing.Color.FromArgb(242, 243, 246);
        _progress.ForeColor = System.Drawing.Color.FromArgb(225, 42, 54);
        _close.BackColor = System.Drawing.Color.FromArgb(170, 26, 42);
        _close.ForeColor = System.Drawing.Color.White;
        Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        Controls.Add(_close);
        Controls.Add(_progress);
        Controls.Add(_status);
        Controls.Add(_headline);
        Controls.Add(_logo);
        using (var logoStream = typeof(Program).Assembly.GetManifestResourceStream("PGC.Connector.Setup.Logo.png"))
        {
            if (logoStream is not null)
            {
                using var sourceImage = System.Drawing.Image.FromStream(logoStream);
                _logo.Image = new System.Drawing.Bitmap(sourceImage);
            }
        }
        _close.Click += (_, _) => Close();
        Shown += async (_, _) => await InstallAsync();
    }

    private async Task InstallAsync()
    {
        try
        {
            await Task.Run(Install);
            _status.Text = "نصب کامل شد. سرویس فعال است و برنامه در منوی Start قرار دارد.";
            MessageBox.Show(this, _status.Text, "PGC Connector", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception error)
        {
            var logPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "PGC", "Connector", "setup-logs", "setup.log");
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
                File.AppendAllText(logPath, $"\n[{DateTimeOffset.Now:O}] {error}\n");
            }
            catch { /* The original installation error remains visible. */ }
            _status.Text = "نصب کامل نشد. جزئیات در گزارش نصب ثبت شده است.";
            MessageBox.Show(this, $"{error.Message}\n\nگزارش: {logPath}", "PGC Connector", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { _progress.Style = ProgressBarStyle.Blocks; _close.Enabled = true; }
    }

    internal static void Install()
    {
        using var identity = WindowsIdentity.GetCurrent();
        if (!new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator))
            throw new InvalidOperationException("دسترسی Administrator داده نشده است.");

        // Program Files has administrator-only write access. Extraction and
        // execution happen only after UAC elevated this very process.
        var staging = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            "PGC Connector Setup Staging", Guid.NewGuid().ToString("N"));
        var logPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "PGC", "Connector", "setup-logs", "setup.log");
        try
        {
            Directory.CreateDirectory(staging);
            using var payload = typeof(Program).Assembly.GetManifestResourceStream("PGC.Connector.Setup.Payload.zip")
                ?? throw new InvalidOperationException("بستهٔ داخلی نصب پیدا نشد.");
            using (var archive = new ZipArchive(payload, ZipArchiveMode.Read))
            {
                var totalSize = archive.Entries.Sum(entry => entry.Length);
                // A self-contained Windows publish contains hundreds of runtime files.
                // Keep a generous file-count bound while still rejecting archive bombs.
                if (totalSize > 500_000_000 || archive.Entries.Count > 5_000)
                    throw new InvalidOperationException("حجم بستهٔ نصب از حد مجاز بیشتر است.");
                archive.ExtractToDirectory(staging);
            }

            var script = Path.Combine(staging, "install.ps1");
            var service = Path.Combine(staging, "service", "PGC.Connector.Service.exe");
            var desktop = Path.Combine(staging, "desktop", "PGC.Connector.Desktop.exe");
            if (!File.Exists(script) || !File.Exists(service) || !File.Exists(desktop))
                throw new InvalidOperationException("فایل‌های مورد نیاز در بستهٔ نصب وجود ندارند.");

            var command = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "WindowsPowerShell", "v1.0", "powershell.exe"))
            {
                UseShellExecute = false, CreateNoWindow = true,
                RedirectStandardOutput = true, RedirectStandardError = true,
                WorkingDirectory = staging
            };
            // A PowerShell 7 parent (for example an automation runner) may pass
            // a PSModulePath without Windows PowerShell's built-in Security module.
            // Restrict elevated module discovery to the Windows-owned directory.
            command.Environment["PSModulePath"] = Path.Combine(Environment.SystemDirectory,
                "WindowsPowerShell", "v1.0", "Modules");
            command.ArgumentList.Add("-NoProfile");
            command.ArgumentList.Add("-ExecutionPolicy");
            command.ArgumentList.Add("Bypass");
            command.ArgumentList.Add("-File");
            command.ArgumentList.Add(script);
            using var process = Process.Start(command) ?? throw new InvalidOperationException("اجرای اسکریپت نصب ممکن نشد.");
            var stdout = process.StandardOutput.ReadToEndAsync();
            var stderr = process.StandardError.ReadToEndAsync();
            process.WaitForExit();
            Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
            File.AppendAllText(logPath, $"\n[{DateTimeOffset.Now:O}] ExitCode={process.ExitCode}\n{stdout.GetAwaiter().GetResult()}\n{stderr.GetAwaiter().GetResult()}\n");
            if (process.ExitCode != 0)
                throw new InvalidOperationException($"اسکریپت نصب با کد {process.ExitCode} متوقف شد.");
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(3) };
            var health = client.GetAsync("http://127.0.0.1:47831/local/health").GetAwaiter().GetResult();
            if (!health.IsSuccessStatusCode)
                throw new InvalidOperationException("سرویس پس از نصب پاسخ سالم نداد.");
        }
        finally
        {
            if (Directory.Exists(staging))
            {
                try { Directory.Delete(staging, true); }
                catch (IOException) { /* Preserve the installation result if cleanup fails. */ }
                catch (UnauthorizedAccessException) { /* A locked staging file can be removed later. */ }
            }
        }
    }
}
