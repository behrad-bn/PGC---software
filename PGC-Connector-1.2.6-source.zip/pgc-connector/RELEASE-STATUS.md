# PGC Connector 1.2.6: release status

This source fixes the desktop elevation requirement, provisions a dedicated
operator SID for access to the local administration token, removes the automatic
launch of a desktop process from the elevated installer, checks the service
health after installation, and makes the Windows build fail on restore, build,
test or publish errors. The interface uses the PGC logo, background, icon and
Vazirmatn fonts already bundled in the desktop project.

The installer is **not** a verified release yet. It must be built on Windows
with .NET 10, installed in a fresh Windows 10/11 x64 VM, and tested with the
same account that installed it. Verify service registration and startup,
Windows Search, a normal-user desktop launch, reboot persistence, upgrade,
uninstall, interrupted installation and corrupted download behavior. Also test
pairing and synchronization against a staging PGC backend and an approved local
vendor API/SDK implementation. The Windows workflow currently performs build,
unit tests and payload inspection; it does not perform these VM tests.

Before distributing commercially, sign the installer and all shipped EXEs
with a trusted code-signing certificate and host downloads on a resumable
distribution endpoint. A SHA-256 file is useful only when distributed through
an independently trusted channel. No vendor integration or production PGC
connection is asserted without vendor credentials and a live end-to-end test.
