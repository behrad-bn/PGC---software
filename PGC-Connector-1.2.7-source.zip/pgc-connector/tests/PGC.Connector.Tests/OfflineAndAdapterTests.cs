using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using PGC.Connector.Core;
using PGC.Connector.Infrastructure;
using PGC.Connector.Infrastructure.Adapters;
using Xunit;

namespace PGC.Connector.Tests;

public sealed class OfflineAndAdapterTests
{
    [Fact]
    public async Task OfflineEventsSurviveStoreRestartAndAreRemovedOnlyAfterAcknowledgement()
    {
        var directory = Path.Combine(Path.GetTempPath(), "pgc-offline-" + Guid.NewGuid().ToString("N"));
        try
        {
            var first = new SqliteOutboxStore(directory);
            await first.InitializeAsync(default);
            await first.EnqueueEventAsync("devices.snapshot", new { device = "PC-1", state = "Busy" }, default);

            // A failed network send never calls MarkEventsSentAsync. Reopen the
            // same database as the service does after restart/reconnection.
            var restarted = new SqliteOutboxStore(directory);
            var pending = await restarted.GetPendingEventsAsync(100, default);
            Assert.Single(pending);
            Assert.Contains("PC-1", pending[0].PayloadJson);

            await restarted.MarkEventsSentAsync([pending[0].Id], default);
            Assert.Empty(await new SqliteOutboxStore(directory).GetPendingEventsAsync(100, default));
        }
        finally
        {
            SqliteConnection.ClearAllPools();
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }
    }

    [Theory]
    [InlineData(VendorKind.GenericRest)]
    [InlineData(VendorKind.GenericSdkBridge)]
    public async Task LocalBridgeCanProbeReserveAndSendConfiguredToken(VendorKind kind)
    {
        var handler = new BridgeHandler();
        var adapter = new ConfigurableRestAdapter(new HttpClient(handler), Settings(kind), kind, "test");
        Assert.True((await adapter.ProbeAsync(default)).Ready);
        var request = new SessionRequest("reservation-1", "PC-1", new CustomerIdentity("user-1", "pgc_user", "Name"), DateTimeOffset.UtcNow, TimeSpan.FromHours(1));
        Assert.True((await adapter.ReserveAsync(request, default)).Success);
        Assert.Equal(2, handler.Requests);
        Assert.All(handler.Tokens, token => Assert.Equal("Bearer test-secret", token));
    }

    [Fact]
    public void SdkBridgeWithoutTokenIsRejectedBeforeContact()
    {
        var settings = Settings(VendorKind.GenericSdkBridge);
        settings.VendorApiToken = string.Empty;
        Assert.Throws<InvalidOperationException>(() => new ConfigurableRestAdapter(new HttpClient(new BridgeHandler()), settings, VendorKind.GenericSdkBridge, "test"));
    }

    [Fact]
    public async Task VendorCapacityConflictIsRejectedAndDoesNotRevealResponseBody()
    {
        var handler = new BridgeHandler { CapacityFull = true };
        var adapter = new ConfigurableRestAdapter(new HttpClient(handler), Settings(VendorKind.GenericRest), VendorKind.GenericRest, "test");
        var request = new SessionRequest("reservation-2", "PC-1", new CustomerIdentity("user-2", "pgc_user2", "Name"), DateTimeOffset.UtcNow, TimeSpan.FromHours(1));
        var result = await adapter.ReserveAsync(request, default);
        Assert.False(result.Success);
        Assert.Equal("vendor-http-error", result.Code);
        Assert.DoesNotContain("secret-reflected-by-vendor", result.Message);
    }

    private static ConnectorSettings Settings(VendorKind kind) => new()
    {
        Vendor = kind,
        VendorBaseUrl = new Uri("http://127.0.0.1:7833"),
        VendorApiToken = "test-secret",
        VendorOptionsJson = JsonSerializer.Serialize(new { enabled = true, routes = new
        {
            health = new { method = "GET", path = "/health" },
            reserve = new { method = "POST", path = "/reserve" }
        } })
    };

    private sealed class BridgeHandler : HttpMessageHandler
    {
        public int Requests { get; private set; }
        public bool CapacityFull { get; init; }
        public List<string> Tokens { get; } = [];

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Requests++;
            Tokens.Add(request.Headers.Authorization?.ToString() ?? "");
            if (request.RequestUri!.AbsolutePath == "/reserve" && CapacityFull)
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.Conflict)
                {
                    Content = new StringContent("secret-reflected-by-vendor", Encoding.UTF8)
                });
            var content = request.RequestUri.AbsolutePath == "/reserve"
                ? "{\"success\":true,\"code\":\"reserved\",\"message\":\"ok\"}"
                : "{}";
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(content, Encoding.UTF8, "application/json")
            });
        }
    }
}
