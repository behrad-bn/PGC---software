$service = Get-Service PGCConnector -ErrorAction SilentlyContinue
$data = Join-Path $env:ProgramData 'PGC\Connector'
[pscustomobject]@{
  Service = if ($service) { $service.Status } else { 'NotInstalled' }
  LocalPort = if (Get-NetTCPConnection -LocalPort 47831 -State Listen -ErrorAction SilentlyContinue) { 'Listening' } else { 'Closed' }
  DataDirectory = $data
  SettingsPresent = Test-Path (Join-Path $data 'settings.bin')
  DatabasePresent = Test-Path (Join-Path $data 'connector.db')
}
Get-ChildItem (Join-Path $data 'logs') -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 3 Name,Length,LastWriteTime
