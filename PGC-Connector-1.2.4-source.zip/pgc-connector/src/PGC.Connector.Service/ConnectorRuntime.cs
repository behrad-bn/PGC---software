using System.Security.Cryptography;
using PGC.Connector.Core;
using PGC.Connector.Infrastructure;

namespace PGC.Connector.Service;

public sealed class ConnectorRuntime(
    ISecureSettingsStore settingsStore,
    IOutboxStore outbox,
    IHttpClientFactory httpClientFactory,
    ConnectorAuditLog audit,
    ILogger<ConnectorRuntime> logger) : BackgroundService
{
    private readonly SemaphoreSlim _runtimeGate = new(1, 1);
    private ConnectorSettings _settings = new();
    private IGamingCenterAdapter? _adapter;
    private DateTimeOffset _nextSnapshot = DateTimeOffset.MinValue;
    private DateTimeOffset _nextHeartbeat = DateTimeOffset.MinValue;
    public AdapterHealth LastAdapterHealth { get; private set; } = new(false, "در حال راه‌اندازی");
    public DateTimeOffset? LastCloudSuccessAt { get; private set; }
    public string Version => typeof(ConnectorRuntime).Assembly.GetName().Version?.ToString(3) ?? "1.1.0";

    public ConnectorSettings Settings => _settings;

    public override async Task StartAsync(CancellationToken cancellationToken)
    {
        await outbox.InitializeAsync(cancellationToken);
        _settings = await settingsStore.LoadAsync(cancellationToken);
        await RebuildAdapterAsync();
        await audit.WriteAsync("info", "service.started", new { Version, machine = Environment.MachineName }, cancellationToken);
        await base.StartAsync(cancellationToken);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await _runtimeGate.WaitAsync(stoppingToken);
                try
                {
                    if (_adapter is null) await RebuildAdapterAsync();
                    LastAdapterHealth = await _adapter!.ProbeAsync(stoppingToken);
                    if (_settings.IsPaired)
                    {
                        await PullCommandsAsync(stoppingToken);
                        await ExecuteCommandsAsync(stoppingToken);
                        if (DateTimeOffset.UtcNow >= _nextSnapshot) await CaptureSnapshotAsync(stoppingToken);
                        await FlushEventsAsync(stoppingToken);
                        if (DateTimeOffset.UtcNow >= _nextHeartbeat) await HeartbeatAsync(stoppingToken);
                    }
                }
                finally { _runtimeGate.Release(); }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception error)
            {
                logger.LogWarning(error, "Connector cycle failed");
                await audit.WriteAsync("warning", "sync.cycle-failed", new { error = error.Message }, stoppingToken);
            }
            await Task.Delay(TimeSpan.FromSeconds(Math.Clamp(_settings.PollSeconds, 2, 60)), stoppingToken);
        }
    }

    public async Task<PairResponse> PairAsync(Uri pgcBaseUrl, string pairCode, string connectorName, CancellationToken cancellationToken)
    {
        if (pgcBaseUrl.Scheme != Uri.UriSchemeHttps && !pgcBaseUrl.IsLoopback)
            throw new InvalidOperationException("PGC Base URL must use HTTPS.");
        if (_settings.IsPaired) throw new InvalidOperationException("برای اتصال مجدد ابتدا اتصال قبلی را Forget کنید.");
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var privateKey = key.ExportPkcs8PrivateKeyPem();
        var publicKey = key.ExportSubjectPublicKeyInfoPem();
        var request = new PairRequest(pairCode.Trim(), connectorName.Trim(), MachineFingerprint(), publicKey, Version);
        var client = new PgcCloudClient(httpClientFactory.CreateClient("pgc-cloud"));
        var result = await client.PairAsync(pgcBaseUrl, request, cancellationToken);

        await _runtimeGate.WaitAsync(cancellationToken);
        try
        {
            _settings.PgcBaseUrl = pgcBaseUrl;
            _settings.ConnectorId = result.ConnectorId;
            _settings.GamenetId = result.GamenetId;
            _settings.GamenetName = result.GamenetName;
            _settings.PrivateKeyPem = privateKey;
            await settingsStore.SaveAsync(_settings, cancellationToken);
        }
        finally { _runtimeGate.Release(); }
        await audit.WriteAsync("info", "pairing.completed", new { result.ConnectorId, result.GamenetId }, cancellationToken);
        return result;
    }

    public async Task UpdateSettingsAsync(SettingsUpdate request, CancellationToken cancellationToken)
    {
        if (request.Vendor is not (VendorKind.GenericRest or VendorKind.GenericSdkBridge))
            throw new InvalidOperationException("فقط نرم‌افزارهای متفرقه با API یا SDK Bridge محلی مجاز هستند.");
        PGC.Connector.Infrastructure.Adapters.NetworkSafety.RequireLocalOrPrivate(request.VendorBaseUrl);
        if (request.VendorOptionsJson.Length > 16_384 || request.VendorApiToken?.Length > 2_048)
            throw new InvalidOperationException("حجم تنظیمات یا کلید Vendor بیش از حد مجاز است.");
        var candidate = new ConnectorSettings
        {
            Vendor = request.Vendor,
            VendorBaseUrl = request.VendorBaseUrl,
            VendorApiToken = request.VendorApiToken ?? _settings.VendorApiToken,
            VendorOptionsJson = request.VendorOptionsJson
        };
        await AdapterFactory.Create(candidate, httpClientFactory.CreateClient("vendor")).DisposeAsync();
        await _runtimeGate.WaitAsync(cancellationToken);
        try
        {
            _settings.Vendor = request.Vendor;
            _settings.VendorBaseUrl = request.VendorBaseUrl;
            if (request.VendorApiToken is not null) _settings.VendorApiToken = request.VendorApiToken;
            _settings.VendorOptionsJson = string.IsNullOrWhiteSpace(request.VendorOptionsJson) ? "{}" : request.VendorOptionsJson;
            _settings.AutoStartSessions = request.AutoStartSessions;
            _settings.AutoStopSessions = request.AutoStopSessions;
            _settings.PollSeconds = Math.Clamp(request.PollSeconds, 2, 60);
            await settingsStore.SaveAsync(_settings, cancellationToken);
            await RebuildAdapterAsync();
        }
        finally { _runtimeGate.Release(); }
        await audit.WriteAsync("info", "settings.updated", new { request.Vendor, request.VendorBaseUrl, request.AutoStartSessions, request.AutoStopSessions }, cancellationToken);
    }

    public async Task ForgetAsync(CancellationToken cancellationToken)
    {
        await _runtimeGate.WaitAsync(cancellationToken);
        try
        {
            if (_settings.IsPaired)
            {
                try { await new PgcCloudClient(httpClientFactory.CreateClient("pgc-cloud")).ForgetAsync(_settings, cancellationToken); }
                catch (Exception error) { await audit.WriteAsync("warning", "pairing.cloud-forget-failed", new { error = error.Message }, cancellationToken); }
            }
            await outbox.ClearPairingDataAsync(cancellationToken);
            await settingsStore.ForgetAsync(cancellationToken);
            _settings = new ConnectorSettings();
            await RebuildAdapterAsync();
        }
        finally { _runtimeGate.Release(); }
        await audit.WriteAsync("info", "pairing.forgotten", null, cancellationToken);
    }

    public async Task<IReadOnlyList<VendorDevice>> GetDevicesAsync(CancellationToken cancellationToken)
    {
        await _runtimeGate.WaitAsync(cancellationToken);
        try { return await _adapter!.GetDevicesAsync(cancellationToken); }
        finally { _runtimeGate.Release(); }
    }
    public Task<IReadOnlyList<DeviceMapping>> GetMappingsAsync(CancellationToken cancellationToken) => outbox.GetMappingsAsync(cancellationToken);
    public Task SaveMappingsAsync(IEnumerable<DeviceMapping> mappings, CancellationToken cancellationToken) => outbox.UpsertMappingsAsync(mappings, cancellationToken);
    public Task<QueueStatistics> GetQueueStatisticsAsync(CancellationToken cancellationToken) => outbox.GetStatisticsAsync(cancellationToken);
    public Task<IReadOnlyList<string>> GetLogsAsync(int take, CancellationToken cancellationToken) => audit.ReadRecentAsync(take, cancellationToken);

    private async Task RebuildAdapterAsync()
    {
        if (_adapter is not null) await _adapter.DisposeAsync();
        _adapter = AdapterFactory.Create(_settings, httpClientFactory.CreateClient("vendor"));
        _nextSnapshot = DateTimeOffset.MinValue;
    }

    private async Task PullCommandsAsync(CancellationToken cancellationToken)
    {
        var client = new PgcCloudClient(httpClientFactory.CreateClient("pgc-cloud"));
        var commands = await client.PullCommandsAsync(_settings, cancellationToken);
        foreach (var command in commands)
        {
            if (command.GamenetId != _settings.GamenetId)
            {
                await audit.WriteAsync("warning", "command.venue-mismatch", new { command.Id }, cancellationToken);
                continue;
            }
            await outbox.SaveIncomingAsync(command, cancellationToken);
        }
        LastCloudSuccessAt = DateTimeOffset.UtcNow;
    }

    private async Task ExecuteCommandsAsync(CancellationToken cancellationToken)
    {
        var executor = new CommandExecutor(_adapter!, outbox);
        foreach (var command in await outbox.GetReadyAsync(50, cancellationToken))
        {
            var result = await executor.ExecuteAsync(command, cancellationToken);
            if (result.State == CommandState.Pending) continue;
            result = await outbox.MarkResultAsync(result, command.IdempotencyKey, cancellationToken);
            await outbox.EnqueueEventAsync("command.result", result, cancellationToken);
            await audit.WriteAsync(result.State == CommandState.Succeeded ? "info" : "warning", "command.completed", new { command.Id, command.Kind, result.State, result.Code }, cancellationToken);
        }
    }

    private async Task CaptureSnapshotAsync(CancellationToken cancellationToken)
    {
        if (!LastAdapterHealth.Ready) { _nextSnapshot = DateTimeOffset.UtcNow.AddSeconds(15); return; }
        var devices = await _adapter!.GetDevicesAsync(cancellationToken);
        await outbox.EnqueueEventAsync("devices.snapshot", new { capturedAt = DateTimeOffset.UtcNow, devices }, cancellationToken);
        _nextSnapshot = DateTimeOffset.UtcNow.AddSeconds(Math.Clamp(_settings.SnapshotSeconds, 10, 300));
    }

    private async Task FlushEventsAsync(CancellationToken cancellationToken)
    {
        var events = await outbox.GetPendingEventsAsync(100, cancellationToken);
        if (events.Count == 0) return;
        await new PgcCloudClient(httpClientFactory.CreateClient("pgc-cloud")).SendEventsAsync(_settings, events, cancellationToken);
        await outbox.MarkEventsSentAsync(events.Select(item => item.Id), cancellationToken);
        LastCloudSuccessAt = DateTimeOffset.UtcNow;
    }

    private async Task HeartbeatAsync(CancellationToken cancellationToken)
    {
        var queue = await outbox.GetStatisticsAsync(cancellationToken);
        await new PgcCloudClient(httpClientFactory.CreateClient("pgc-cloud")).SendHeartbeatAsync(
            _settings, LastAdapterHealth, _adapter!.Capabilities, queue, Version, cancellationToken);
        LastCloudSuccessAt = DateTimeOffset.UtcNow;
        _nextHeartbeat = DateTimeOffset.UtcNow.AddSeconds(30);
    }

    private static string MachineFingerprint()
    {
        var raw = $"{Environment.MachineName}|{Environment.OSVersion}|{Environment.ProcessorCount}";
        return Convert.ToHexStringLower(SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(raw)));
    }
}

public sealed record SettingsUpdate(VendorKind Vendor, Uri VendorBaseUrl, string? VendorApiToken, string VendorOptionsJson,
    bool AutoStartSessions, bool AutoStopSessions, int PollSeconds);
