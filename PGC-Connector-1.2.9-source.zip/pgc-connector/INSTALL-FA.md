# نصب PGC Connector 1.1 روی Windows 10/11 x64

## روش پیشنهادی: بسته آماده نصب

این روش به نصب .NET SDK نیاز ندارد.

1. فایل `PGC-Connector-1.1.0-Windows-x64-ready.zip` را دانلود کنید.
2. روی فایل راست‌کلیک کنید و `Extract All` را بزنید.
3. Windows PowerShell را با `Run as administrator` باز کنید.
4. دستور زیر را کامل اجرا کنید؛ فقط اگر فایل را جای دیگری Extract کرده‌اید، مقدار `$Folder` را تغییر دهید:

```powershell
$Folder = "$env:USERPROFILE\Downloads\PGC-Connector-1.1.0-Windows-x64-ready"
Set-ExecutionPolicy -Scope Process Bypass -Force
Set-Location $Folder
Unblock-File -Path ".\*.ps1"
.\install.ps1
```

پس از پایان نصب، در Windows Search عبارت `PGC Connector` را جست‌وجو و برنامه را اجرا کنید. سرویس اصلی مستقل از پنجره برنامه و به‌صورت خودکار در پس‌زمینه ویندوز اجرا می‌شود.

## روش دوم: ساخت و نصب از سورس

1. فایل `PGC-Connector-v1.1.0-source-2026-09-18.zip` را دانلود و Extract کنید.
2. Windows PowerShell را با `Run as administrator` باز کنید.
3. دستور زیر را کامل اجرا کنید:

```powershell
$Folder = "$env:USERPROFILE\Downloads\PGC-Connector-v1.1.0-source-2026-09-18"
Set-ExecutionPolicy -Scope Process Bypass -Force
Set-Location $Folder
Unblock-File -Path ".\scripts\*.ps1"
.\scripts\setup.ps1
```

`setup.ps1` وجود .NET 10 SDK را بررسی می‌کند، در صورت نبودن آن از winget برای نصب استفاده می‌کند، Restore/Build/Test/Publish را انجام می‌دهد و سپس Connector را نصب می‌کند.

## بررسی وضعیت نصب

```powershell
Get-Service PGCConnector
Get-Item "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\PGC Connector\PGC Connector.lnk"
Start-Process "$env:ProgramFiles\PGC Connector\desktop\PGC.Connector.Desktop.exe"
```

وضعیت سرویس باید `Running` باشد و فایل Shortcut باید بدون خطا پیدا شود.

## حذف برنامه

PowerShell را با دسترسی Administrator باز کنید:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
& "$env:ProgramFiles\PGC Connector\uninstall.ps1"
```

اطلاعات و صف آفلاین حفظ می‌شوند. برای حذف داده‌ها نیز از پارامتر `-PurgeData` استفاده کنید.
