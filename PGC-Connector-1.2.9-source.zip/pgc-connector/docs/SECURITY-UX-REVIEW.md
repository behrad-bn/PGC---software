# بازبینی نهایی UI/UX، امنیت و دسترسی

## UI/UX

- رابط فارسی RTL و هم‌زبان با PGC: زمینه مشکی، قرمز تیره، خاکستری و متن روشن.
- Dashboard به‌جای جزئیات فنی، چهار وضعیت تصمیم‌ساز را نشان می‌دهد: Cloud، Adapter، صف فرمان و صف رویداد.
- Pairing، تنظیم Vendor، دستگاه‌ها و گزارش‌ها در Tabهای جدا هستند.
- وضعیت خطا، آفلاین و آماده با متن و رنگ هم‌زمان نمایش داده می‌شود؛ وابسته به رنگ تنها نیست.
- پنل وب PGC صفحه جدا برای وضعیت Connector، کد Pair، آخرین heartbeat، نگاشت دستگاه و Issueها دارد.
- عملیات خطرناک Forget/Revoke تأیید صریح دارد.

## امنیت

- ECDSA P-256، SHA-256 بدنه، timestamp، nonce پایدار و جلوگیری از replay.
- کلید خصوصی DPAPI و ACL محدود به SYSTEM/Administrators.
- API محلی فقط loopback و با توکن ۲۵۶ بیتی.
- HTTPS اجباری برای PGC به‌جز loopback توسعه.
- Rate limit جدا برای Pairing و درخواست‌های امضاشده.
- Validation محدود برای طول فیلدها، کلید عمومی، enum، URL و مسیر Adapter.
- Outbox آفلاین، idempotency، expiry، retry با backoff و Dead Letter.
- کلید عمومی و fingerprint hash هرگز به پاسخ مالک برگردانده نمی‌شوند.

## دسترسی

- Owner فقط Connector و mapping گیم‌نت خودش را می‌بیند/ویرایش می‌کند.
- Admin دسترسی مدیریتی دارد.
- Endpointهای Owner همچنان CSRF و session cookie را الزامی می‌دانند.
- Endpointهای Machine به cookie متکی نیستند و فقط با امضای Connector فعال می‌شوند.
- Integration entityها به API عمومی generic اضافه نشده‌اند؛ بنابراین دورزدن UI از مسیر `/api/entities` ممکن نیست.

## موارد الزامی پیش از Production

1. دریافت API key و مستند رسمی نسخه نصب‌شده ggLeap و LaunchDesk.
2. تست Pilot روی یک Smartlaunch واقعی؛ مستند موجود قدیمی است.
3. Code signing فایل‌های EXE و PowerShell با گواهی سازمانی PGC.
4. Pen-test مستقل روی endpointهای Integration و فرآیند update.
5. تعریف فرایند rotation/revocation کلید و انتشار به‌روزرسانی امضاشده.
