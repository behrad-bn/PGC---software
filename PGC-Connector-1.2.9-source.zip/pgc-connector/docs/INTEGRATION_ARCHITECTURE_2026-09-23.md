# معماری اتصال PGC — وضعیت قابل اجرا و پیش‌نیازهای فروشنده

این قرارداد تصمیم معماری است؛ اعلام آماده‌بودن API یا OAuth فروشندگان نیست.

| گروه | اجرای اتصال | احراز هویت | وضعیت واقعی |
|---|---|---|---|
| ggLeap | Integration Service در Backend وب‌سایت، اتصال Cloud | API token مرکز، فقط پس از اخذ قرارداد و مستندات | Cloud adapter و Credential واقعی در این سورس پیاده‌سازی نشده‌اند. |
| Smartlaunch | Integration Service در Backend در صورت وجود Cloud API | OAuth طبق طرح موردنظر PGC، فقط پس از تأیید Vendor | مستند REST محلی وجود دارد؛ OAuth/Cloud آن تأیید نشده است. |
| Launch Desk | Integration Service در Backend در صورت وجود Cloud API | OAuth مشروط به قرارداد Vendor | API/OAuth رسمی در منابع عمومی تأیید نشده است. |
| Game Manager | Integration Service در Backend در صورت وجود Cloud API | OAuth مشروط به قرارداد Vendor | API/OAuth رسمی در منابع عمومی تأیید نشده است. |
| نرم‌افزار متفرقه با API | سرویس ویندوز PGC Connect، REST در شبکهٔ محلی | توکن یا روش تأییدشدهٔ Vendor | Adapter قابل پیکربندی، نیازمند endpoint واقعی و تست Vendor. |
| نرم‌افزار متفرقه با SDK | SDK فروشنده در پردازش واسط مستقل؛ PGC Connect به HTTP loopback آن وصل می‌شود | توکن اختصاصی بین Connector و Bridge؛ احراز هویت خود SDK طبق قرارداد Vendor | قرارداد Bridge آماده است؛ هر SDK اختصاصی به مجوز و پیاده‌سازی واقعی نیاز دارد. |
| بدون رابط رسمی | مدیریت دستی در پنل PGC | ورود معمول صاحب گیم‌نت | هیچ خودکاری برای ظرفیت یا Session ادعا نمی‌شود. |

## قرارداد SDK Bridge

Bridge تحت حساب کم‌دسترسی مستقل از Windows Service اجرا شود؛ هرگز DLL فروشنده داخل پردازش سرویس PGC (LocalSystem) بارگذاری نشود. Bridge صرفاً به `127.0.0.1` گوش دهد، برای هر درخواست توکن اختصاصی `Bearer` دریافت کند، JSON نرمال‌شده برگرداند و به طور صریح قابلیت‌ها را اعلام کند. برای عملیات تغییر دهنده، شناسهٔ رزرو یا کلید idempotency حفظ شود. این Bridge فقط پس از داشتن SDK رسمی Vendor قابل تولید است. در صفحهٔ تنظیمات، حالت «SDK Bridge محلی» همین پروتکل را مصرف می‌کند؛ فیلد Routes شامل `health`, `devices`, `ensureCustomer`, `reserve`, `cancelReservation`, `startSession`, `stopSession`, `power` است. پاسخ هر عملیات باید شیء JSON با `success`, `code`, `message`, `externalReference` باشد.

## آفلاین و ظرفیت

سرویس Windows داده‌های ورودی و رویدادها را در SQLite با WAL نگه می‌دارد؛ بعد از بازگشت اینترنت، فرمان‌ها/رویدادها را دوباره ارسال می‌کند. Backend برای گیم‌نتی که Connector فعال دارد، بدون heartbeat و inventory تازه (حداکثر ۹۰ ثانیه) ظرفیت آزاد برنمی‌گرداند. حالت `Unconfigured` هیچ ظرفیت ساختگی تولید نمی‌کند.

تازه‌بودن snapshot به تنهایی تضمین نمی‌کند در فاصلهٔ بین نمایش ظرفیت و پرداخت، مشتری محلی یا سیستم دیگری همان دستگاه را نگیرد. برای تضمین واقعی، Vendor باید رزرو اتمی/hold یا API ظرفیت در لحظه بدهد؛ تا دریافت آن، رزرو قطعی بدون تأیید Vendor نباید وعده داده شود. هنگام قطع اینترنت، صف محلی سفارش‌های قبلاً تأییدشده را حفظ می‌کند، اما رزرو جدید با دادهٔ قدیمی نباید تأیید شود.

## حدود تحویل و آزمون

مقایسهٔ قرارداد Pair، فرمان‌ها، Event batch، Heartbeat و Forget در سورس PGC website و Connector انجام می‌شود. اتصال به وب‌سایت تولیدی، سرویس OAuth فروشندگان، و نصب واقعی روی Windows فقط بعد از Deployment Backend، حساب آزمایشی Vendor و میزبان Windows قابل آزمون هستند.
