# معماری و قواعد مالکیت داده

مسیر فرمان:

`PGC Website → Integration Service → Signed HTTPS → Windows Service → Vendor Adapter`

مسیر رویداد:

`Vendor Adapter → SQLite Outbox → Signed HTTPS → Integration Service → PGC Website`

## قواعد قطعی

- PGC مرجع نهایی رزرو، زمان، پرداخت و هویت PGC است.
- نرم‌افزار داخلی مرجع Session فعال و وضعیت لحظه‌ای دستگاه است.
- Connector فرمان تکراری را با `idempotencyKey` دوباره اجرا نمی‌کند.
- فرمان زمان‌دار قبل از `notBefore` اجرا نمی‌شود و بعد از `expiresAt` به Dead Letter می‌رود.
- خطای Vendor با backoff نمایی تا ۱۰ بار retry می‌شود.
- قطع اینترنت باعث حذف رویداد یا فرمان دریافت‌شده نمی‌شود؛ SQLite با WAL و `synchronous=FULL` آن را نگه می‌دارد.
- رزرو فعال محلی فقط با فرمان صریح PGC پایان می‌یابد؛ snapshot قدیمی به‌تنهایی باعث قطع Session نمی‌شود.

## امنیت ارتباط Cloud

هر Connector یک کلید ECDSA P-256 روی همان سیستم می‌سازد. کلید خصوصی هرگز به وب‌سایت ارسال نمی‌شود. هر درخواست شامل شناسه Connector، timestamp، nonce، SHA-256 بدنه و امضای DER است. سرور:

1. اختلاف ساعت را حداکثر ۵ دقیقه می‌پذیرد.
2. hash بدنه خام را مقایسه می‌کند.
3. امضا را با کلید عمومی Pair‌شده تأیید می‌کند.
4. nonce را ذخیره می‌کند تا replay حتی پس از restart رد شود.
5. Connector باطل‌شده را رد می‌کند.

Pairing با کد ۸ رقمی یک‌بارمصرف و اعتبار ۱۰ دقیقه انجام می‌شود. دسترسی ساخت کد، نگاشت دستگاه و ابطال Connector فقط برای مالک همان گیم‌نت یا Admin است.
