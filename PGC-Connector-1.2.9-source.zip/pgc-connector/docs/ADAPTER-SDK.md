# قرارداد Adapter سفارشی

برای `ggLeap`، `LaunchDesk` یا هر نرم‌افزار دیگر، تا وقتی مستند رسمی دریافت نشده است از `GenericRest` استفاده کنید. نمونه `VendorOptionsJson`:

```json
{
  "enabled": true,
  "allowPublicHttps": false,
  "tokenScheme": "Bearer",
  "routes": {
    "health": { "method": "GET", "path": "/pgc/health" },
    "devices": { "method": "GET", "path": "/pgc/devices" },
    "ensureCustomer": { "method": "POST", "path": "/pgc/customers/ensure" },
    "reserve": { "method": "POST", "path": "/pgc/reservations" },
    "cancelReservation": { "method": "POST", "path": "/pgc/reservations/cancel" },
    "startSession": { "method": "POST", "path": "/pgc/sessions/start" },
    "stopSession": { "method": "POST", "path": "/pgc/sessions/stop" },
    "power": { "method": "POST", "path": "/pgc/devices/power" }
  }
}
```

`devices` باید آرایه‌ای از ساختار زیر برگرداند:

```json
[{"externalId":"PC-01","name":"PC 01","deviceType":"PC","state":"Available","activeCustomer":null}]
```

Endpointهای فرمان باید HTTP موفق و ترجیحاً پاسخ زیر را برگردانند:

```json
{"success":true,"code":"ok","message":"انجام شد","externalReference":"optional"}
```

نکات امنیتی:

- HTTP عمومی پذیرفته نمی‌شود.
- به‌صورت پیش‌فرض فقط loopback و IP خصوصی مجاز است.
- HTTPS عمومی فقط با `allowPublicHttps=true` فعال می‌شود.
- مسیرها باید با `/` شروع شوند و `..` مجاز نیست.
- Token در DPAPI ذخیره می‌شود و در API محلی بازگردانده نمی‌شود.
