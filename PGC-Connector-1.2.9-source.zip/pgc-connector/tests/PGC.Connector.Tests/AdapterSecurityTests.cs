using System.Net;
using System.Text;
using System.Text.Json;
using PGC.Connector.Core;
using PGC.Connector.Infrastructure;
using PGC.Connector.Infrastructure.Adapters;
using Xunit;

namespace PGC.Connector.Tests;

public sealed class AdapterSecurityTests
{
    [Theory]
    [InlineData("//attacker.example/steal")]
    [InlineData("/..\\secret")]
    [InlineData("/%2f%2fattacker.example")]
    public async Task VendorRoute_CannotEscapeConfiguredHost(string route)
    {
        var handler = new RecordingHandler();
        var adapter = new ConfigurableRestAdapter(new HttpClient(handler), Settings(route), VendorKind.GenericRest, "test");
        await Assert.ThrowsAsync<InvalidOperationException>(() => adapter.GetDevicesAsync(default));
        Assert.Equal(0, handler.Requests);
    }

    [Fact]
    public async Task InvalidVendorResponse_DoesNotBecomeSuccess()
    {
        var handler = new RecordingHandler();
        var adapter = new ConfigurableRestAdapter(new HttpClient(handler), Settings("/devices"), VendorKind.GenericRest, "test");
        var result = await adapter.ReserveAsync(new SessionRequest("r1", "pc1", new CustomerIdentity("u1", "user", "Name"),
            DateTimeOffset.UtcNow, TimeSpan.FromHours(1)), default);
        Assert.False(result.Success);
        Assert.Equal("vendor-invalid-response", result.Code);
    }

    [Fact]
    public async Task Simulator_IsUnconfiguredInProduction()
    {
        var adapter = AdapterFactory.Create(new ConnectorSettings(), new HttpClient());
        Assert.False(adapter.Capabilities.DeviceInventory);
        Assert.False((await adapter.ProbeAsync(default)).Ready);
    }

    private static ConnectorSettings Settings(string route) => new()
    {
        Vendor = VendorKind.GenericRest,
        VendorBaseUrl = new Uri("http://127.0.0.1:7833"),
        VendorOptionsJson = JsonSerializer.Serialize(new { enabled = true, routes = new
        {
            devices = new { method = "GET", path = route },
            reserve = new { method = "POST", path = "/reserve" }
        } })
    };

    private sealed class RecordingHandler : HttpMessageHandler
    {
        public int Requests { get; private set; }
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Requests++;
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("not-json", Encoding.UTF8, "application/json")
            });
        }
    }
}
