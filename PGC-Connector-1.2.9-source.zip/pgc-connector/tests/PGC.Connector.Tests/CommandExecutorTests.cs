using System.Text.Json;
using PGC.Connector.Core;
using Xunit;

namespace PGC.Connector.Tests;

public sealed class CommandExecutorTests
{
    [Fact]
    public async Task NestedCustomerPayload_IsPassedToAdapter()
    {
        var adapter = new FakeAdapter();
        var command = Command(CommandKind.StartSession, """
            {"externalDeviceId":"pc-01","customer":{"pgcUserId":"u1","externalUsername":"pgc_user","displayName":"کاربر تست"},"startsAt":"2026-09-18T10:00:00Z","durationMinutes":90}
            """);

        var result = await new CommandExecutor(adapter, new FakeStore()).ExecuteAsync(command, default);

        Assert.Equal(CommandState.Succeeded, result.State);
        Assert.Equal("pc-01", adapter.LastSession?.ExternalDeviceId);
        Assert.Equal("pgc_user", adapter.LastSession?.Customer.ExternalUsername);
        Assert.Equal(TimeSpan.FromMinutes(90), adapter.LastSession!.Duration);
    }

    [Fact]
    public async Task ProcessedIdempotencyKey_DoesNotRunVendorAgain()
    {
        var adapter = new FakeAdapter();
        var store = new FakeStore { Processed = true };
        var result = await new CommandExecutor(adapter, store).ExecuteAsync(Command(CommandKind.StartSession, "{}"), default);
        Assert.Equal("already-processed", result.Code);
        Assert.Equal(0, adapter.Calls);
    }

    [Fact]
    public async Task ExpiredCommand_IsDeadLettered()
    {
        var adapter = new FakeAdapter();
        var command = Command(CommandKind.StartSession, "{}") with { ExpiresAt = DateTimeOffset.UtcNow.AddMinutes(-1) };
        var result = await new CommandExecutor(adapter, new FakeStore()).ExecuteAsync(command, default);
        Assert.Equal(CommandState.DeadLetter, result.State);
        Assert.Equal(0, adapter.Calls);
    }

    private static ConnectorCommand Command(CommandKind kind, string json) => new(
        "command-1", "idempotency-1", kind, "venue-1", "reservation-1", DateTimeOffset.UtcNow,
        null, DateTimeOffset.UtcNow.AddHours(1), JsonDocument.Parse(json).RootElement.Clone());

    private sealed class FakeAdapter : IGamingCenterAdapter
    {
        public int Calls { get; private set; }
        public SessionRequest? LastSession { get; private set; }
        public VendorKind Kind => VendorKind.Simulator;
        public string DisplayName => "Fake";
        public AdapterCapabilities Capabilities => new(true, true, true, true, true, false);
        public Task<AdapterHealth> ProbeAsync(CancellationToken cancellationToken) => Task.FromResult(new AdapterHealth(true, "ok"));
        public Task<IReadOnlyList<VendorDevice>> GetDevicesAsync(CancellationToken cancellationToken) => Task.FromResult<IReadOnlyList<VendorDevice>>([]);
        public Task<AdapterResult> EnsureCustomerAsync(CustomerIdentity customer, CancellationToken cancellationToken) { Calls++; return Task.FromResult(AdapterResult.Ok()); }
        public Task<AdapterResult> ReserveAsync(SessionRequest request, CancellationToken cancellationToken) { Calls++; LastSession = request; return Task.FromResult(AdapterResult.Ok()); }
        public Task<AdapterResult> CancelReservationAsync(string externalReference, CancellationToken cancellationToken) { Calls++; return Task.FromResult(AdapterResult.Ok()); }
        public Task<AdapterResult> StartSessionAsync(SessionRequest request, CancellationToken cancellationToken) { Calls++; LastSession = request; return Task.FromResult(AdapterResult.Ok()); }
        public Task<AdapterResult> StopSessionAsync(string externalUsername, CancellationToken cancellationToken) { Calls++; return Task.FromResult(AdapterResult.Ok()); }
        public Task<AdapterResult> PowerAsync(string externalDeviceId, bool on, CancellationToken cancellationToken) { Calls++; return Task.FromResult(AdapterResult.Ok()); }
        public ValueTask DisposeAsync() => ValueTask.CompletedTask;
    }

    private sealed class FakeStore : IOutboxStore
    {
        public bool Processed { get; init; }
        public Task<bool> IsProcessedAsync(string idempotencyKey, CancellationToken cancellationToken) => Task.FromResult(Processed);
        public Task InitializeAsync(CancellationToken cancellationToken) => Task.CompletedTask;
        public Task SaveIncomingAsync(ConnectorCommand command, CancellationToken cancellationToken) => Task.CompletedTask;
        public Task<IReadOnlyList<ConnectorCommand>> GetReadyAsync(int take, CancellationToken cancellationToken) => Task.FromResult<IReadOnlyList<ConnectorCommand>>([]);
        public Task<CommandExecutionResult> MarkResultAsync(CommandExecutionResult result, string idempotencyKey, CancellationToken cancellationToken) => Task.FromResult(result);
        public Task EnqueueEventAsync(string eventType, object payload, CancellationToken cancellationToken) => Task.CompletedTask;
        public Task<IReadOnlyList<OutboxEvent>> GetPendingEventsAsync(int take, CancellationToken cancellationToken) => Task.FromResult<IReadOnlyList<OutboxEvent>>([]);
        public Task MarkEventsSentAsync(IEnumerable<string> ids, CancellationToken cancellationToken) => Task.CompletedTask;
        public Task UpsertMappingsAsync(IEnumerable<DeviceMapping> mappings, CancellationToken cancellationToken) => Task.CompletedTask;
        public Task<IReadOnlyList<DeviceMapping>> GetMappingsAsync(CancellationToken cancellationToken) => Task.FromResult<IReadOnlyList<DeviceMapping>>([]);
        public Task<QueueStatistics> GetStatisticsAsync(CancellationToken cancellationToken) => Task.FromResult(new QueueStatistics(0, 0, 0, null));
        public Task ClearPairingDataAsync(CancellationToken cancellationToken) => Task.CompletedTask;
    }
}
