﻿param([string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$out = Join-Path $root 'artifacts'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET 10 SDK is required.' }
dotnet --info
dotnet restore (Join-Path $root 'PGC.Connector.sln') --disable-parallel
if ($LASTEXITCODE -ne 0) { throw 'Restore failed.' }
dotnet build (Join-Path $root 'PGC.Connector.sln') -c $Configuration --no-restore -m:1 -nr:false
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
dotnet test (Join-Path $root 'tests\PGC.Connector.Tests\PGC.Connector.Tests.csproj') -c $Configuration --no-build -m:1 -nr:false
if ($LASTEXITCODE -ne 0) { throw 'Tests failed.' }
New-Item -ItemType Directory -Force $out | Out-Null
dotnet publish (Join-Path $root 'src\PGC.Connector.Service\PGC.Connector.Service.csproj') -c $Configuration -r win-x64 --self-contained true -o (Join-Path $out 'service')
if ($LASTEXITCODE -ne 0) { throw 'Service publish failed.' }
dotnet publish (Join-Path $root 'src\PGC.Connector.Desktop\PGC.Connector.Desktop.csproj') -c $Configuration -r win-x64 --self-contained true -o (Join-Path $out 'desktop')
if ($LASTEXITCODE -ne 0) { throw 'Desktop publish failed.' }
Copy-Item (Join-Path $root 'scripts\install.ps1') $out
Copy-Item (Join-Path $root 'scripts\uninstall.ps1') $out
Copy-Item (Join-Path $root 'scripts\diagnostics.ps1') $out
Copy-Item (Join-Path $root 'scripts\setup.ps1') $out
$payload = Join-Path (Split-Path -Parent $root) 'output\pgc-installer-payload.zip'
New-Item -ItemType Directory -Force (Split-Path -Parent $payload) | Out-Null
$payloadPaths = @(
  (Join-Path $out 'service')
  (Join-Path $out 'desktop')
  (Join-Path $out 'install.ps1')
  (Join-Path $out 'uninstall.ps1')
  (Join-Path $out 'diagnostics.ps1')
)
Compress-Archive -Path $payloadPaths -DestinationPath $payload -CompressionLevel Optimal -Force
dotnet publish (Join-Path $root 'installer\PGC.Connector.Setup\PGC.Connector.Setup.csproj') -c $Configuration -r win-x64 --self-contained true -o (Join-Path $out 'installer')
if ($LASTEXITCODE -ne 0) { throw 'ساخت نصب‌کننده ناموفق بود.' }
Get-ChildItem $out -Recurse -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($out.Length + 1))" } | Set-Content (Join-Path $out 'SHA256SUMS.txt') -Encoding utf8
Write-Host "Release ready: $out"
