﻿#Requires -RunAsAdministrator
param([switch]$PurgeData)
$ErrorActionPreference = 'Stop'
$serviceName = 'PGCConnector'
if (Get-Service $serviceName -ErrorAction SilentlyContinue) {
  Stop-Service $serviceName -Force -ErrorAction SilentlyContinue
  & sc.exe delete $serviceName | Out-Null
}
$target = Join-Path $env:ProgramFiles 'PGC Connector'
if (Test-Path $target) { Remove-Item $target -Recurse -Force }
$shortcut = Join-Path $env:Public 'Desktop\PGC Connector.lnk'
if (Test-Path $shortcut) { Remove-Item $shortcut -Force }
$startMenuDirectory = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\PGC Connector'
if (Test-Path $startMenuDirectory) { Remove-Item $startMenuDirectory -Recurse -Force }
$appPathKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\PGC Connector.exe'
if (Test-Path $appPathKey) { Remove-Item $appPathKey -Recurse -Force }
$uninstallKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PGC Connector'
if (Test-Path $uninstallKey) { Remove-Item $uninstallKey -Recurse -Force }
if ($PurgeData) {
  $data = Join-Path $env:ProgramData 'PGC\Connector'
  if (Test-Path $data) { Remove-Item $data -Recurse -Force }
}
Write-Host 'PGC Connector removed. Data was preserved unless -PurgeData was supplied.'
