﻿#Requires -Version 5.1
#Requires -RunAsAdministrator

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$artifacts = Join-Path $root 'artifacts'

function Get-DotnetExecutable {
  $programFilesDotnet = Join-Path $env:ProgramFiles 'dotnet\dotnet.exe'
  if (Test-Path $programFilesDotnet) { return $programFilesDotnet }
  $command = Get-Command dotnet.exe -ErrorAction SilentlyContinue
  if ($command) { return $command.Source }
  return $null
}

$dotnet = Get-DotnetExecutable
if (-not $dotnet) {
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if (-not $winget) {
    throw '.NET 10 SDK نصب نیست و winget نیز پیدا نشد. ابتدا .NET 10 SDK x64 را از dotnet.microsoft.com نصب کنید.'
  }
  Write-Host 'Installing .NET 10 SDK...'
  & $winget.Source install --id Microsoft.DotNet.SDK.10 --exact --source winget --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) { throw 'نصب .NET 10 SDK با winget ناموفق بود.' }
  $dotnet = Get-DotnetExecutable
}
if (-not $dotnet) { throw 'dotnet.exe بعد از نصب پیدا نشد. Windows را یک‌بار Restart کنید و setup.ps1 را دوباره اجرا کنید.' }

$sdkVersionText = (& $dotnet --version).Trim()
$sdkVersion = [Version]($sdkVersionText -replace '-.*$', '')
if ($sdkVersion.Major -lt 10) {
  throw ".NET 10 SDK لازم است؛ نسخه پیدا شده: $sdkVersionText"
}

Write-Host "Using .NET SDK $sdkVersionText"
& $dotnet restore (Join-Path $root 'PGC.Connector.sln') --disable-parallel
if ($LASTEXITCODE -ne 0) { throw 'dotnet restore ناموفق بود.' }
& $dotnet build (Join-Path $root 'PGC.Connector.sln') --configuration Release --no-restore -m:1 -nr:false
if ($LASTEXITCODE -ne 0) { throw 'dotnet build ناموفق بود.' }
& $dotnet test (Join-Path $root 'tests\PGC.Connector.Tests\PGC.Connector.Tests.csproj') --configuration Release --no-build --no-restore -m:1 -nr:false
if ($LASTEXITCODE -ne 0) { throw 'آزمون‌های Connector ناموفق بودند و نصب متوقف شد.' }

if (Test-Path $artifacts) { Remove-Item $artifacts -Recurse -Force }
New-Item -ItemType Directory -Force $artifacts | Out-Null
& $dotnet publish (Join-Path $root 'src\PGC.Connector.Service\PGC.Connector.Service.csproj') --configuration Release --runtime win-x64 --self-contained true --no-restore --output (Join-Path $artifacts 'service')
if ($LASTEXITCODE -ne 0) { throw 'Publish سرویس ناموفق بود.' }
& $dotnet publish (Join-Path $root 'src\PGC.Connector.Desktop\PGC.Connector.Desktop.csproj') --configuration Release --runtime win-x64 --self-contained true --no-restore --output (Join-Path $artifacts 'desktop')
if ($LASTEXITCODE -ne 0) { throw 'Publish رابط کاربری ناموفق بود.' }

Copy-Item (Join-Path $root 'scripts\install.ps1') $artifacts
Copy-Item (Join-Path $root 'scripts\uninstall.ps1') $artifacts
Copy-Item (Join-Path $root 'scripts\diagnostics.ps1') $artifacts

Write-Host 'Build and tests completed. Installing PGC Connector...'
& (Join-Path $artifacts 'install.ps1')
if ($LASTEXITCODE -ne 0) { throw 'نصب PGC Connector ناموفق بود.' }

Write-Host ''
Write-Host 'PGC Connector 1.2 installed successfully.' -ForegroundColor Green
Write-Host 'You can now search Windows for: PGC Connector'
