using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;

namespace PGC.Connector.Service;

public sealed class LocalAdminToken
{
    public string Value { get; }

    public LocalAdminToken()
    {
        Directory.CreateDirectory(ConnectorPaths.DataDirectory);
        if (!File.Exists(ConnectorPaths.LocalTokenPath))
        {
            File.WriteAllText(ConnectorPaths.LocalTokenPath, Convert.ToHexString(RandomNumberGenerator.GetBytes(32)));
        }
        HardenAcl();
        Value = File.ReadAllText(ConnectorPaths.LocalTokenPath).Trim();
        if (Value.Length != 64 || !Value.All(Uri.IsHexDigit))
            throw new InvalidOperationException("Local admin token is invalid.");
    }

    private static void HardenAcl()
    {
        if (!OperatingSystem.IsWindows()) return;
        var security = new FileSecurity();
        security.SetAccessRuleProtection(true, false);
        security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), FileSystemRights.FullControl, AccessControlType.Allow));
        security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null), FileSystemRights.FullControl, AccessControlType.Allow));
        var operatorSid = ConnectorPaths.OperatorSid();
        if (operatorSid is not null)
            security.AddAccessRule(new FileSystemAccessRule(operatorSid, FileSystemRights.Read, AccessControlType.Allow));
        new FileInfo(ConnectorPaths.LocalTokenPath).SetAccessControl(security);
    }
}
