using System.Text.Json;

namespace PGC.Connector.Service;

public sealed class ConnectorAuditLog
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);

    public async Task WriteAsync(string level, string eventName, object? data, CancellationToken cancellationToken = default)
    {
        Directory.CreateDirectory(ConnectorPaths.LogDirectory);
        var line = JsonSerializer.Serialize(new { at = DateTimeOffset.UtcNow, level, eventName, data }, _json) + Environment.NewLine;
        var path = Path.Combine(ConnectorPaths.LogDirectory, $"connector-{DateTime.UtcNow:yyyy-MM-dd}.jsonl");
        await _gate.WaitAsync(cancellationToken);
        try { await File.AppendAllTextAsync(path, line, cancellationToken); }
        finally { _gate.Release(); }
    }

    public async Task<IReadOnlyList<string>> ReadRecentAsync(int take, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(ConnectorPaths.LogDirectory);
        var path = Path.Combine(ConnectorPaths.LogDirectory, $"connector-{DateTime.UtcNow:yyyy-MM-dd}.jsonl");
        if (!File.Exists(path)) return [];
        var lines = await File.ReadAllLinesAsync(path, cancellationToken);
        return lines.TakeLast(Math.Clamp(take, 1, 500)).Reverse().ToArray();
    }
}
