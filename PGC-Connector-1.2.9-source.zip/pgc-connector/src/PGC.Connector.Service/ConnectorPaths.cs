using System.Security.AccessControl;
using System.Security.Principal;

namespace PGC.Connector.Service;

public static class ConnectorPaths
{
    public static string DataDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "PGC", "Connector");
    public static string LogDirectory => Path.Combine(DataDirectory, "logs");
    public static string LocalTokenPath => Path.Combine(DataDirectory, "local-admin-token.txt");
    public static string OwnerSidPath => Path.Combine(DataDirectory, "owner-sid.txt");

    public static SecurityIdentifier? OperatorSid()
    {
        if (!File.Exists(OwnerSidPath)) return null;
        var value = File.ReadAllText(OwnerSidPath).Trim();
        return new SecurityIdentifier(value);
    }

    public static void EnsureSecureDirectory()
    {
        Directory.CreateDirectory(DataDirectory);
        if (!OperatingSystem.IsWindows()) return;
        var security = new DirectorySecurity();
        security.SetAccessRuleProtection(true, false);
        var inheritance = InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit;
        security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null),
            FileSystemRights.FullControl, inheritance, PropagationFlags.None, AccessControlType.Allow));
        security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null),
            FileSystemRights.FullControl, inheritance, PropagationFlags.None, AccessControlType.Allow));
        var operatorSid = OperatorSid();
        if (operatorSid is not null)
            security.AddAccessRule(new FileSystemAccessRule(operatorSid, FileSystemRights.ReadAndExecute,
                inheritance, PropagationFlags.None, AccessControlType.Allow));
        new DirectoryInfo(DataDirectory).SetAccessControl(security);
    }
}
