using System.Text.Json;

namespace PGC.Connector.Core;

public enum VendorKind { Simulator, Smartlaunch, GgLeap, LaunchDesk, GenericRest, GenericSdkBridge }
public enum DeviceState { Unknown, Available, Reserved, InUse, Offline, Maintenance }
public enum CommandKind { EnsureCustomer, ReserveDevice, CancelReservation, StartSession, StopSession, PowerOn, PowerOff, RefreshInventory }
public enum CommandState { Pending, Processing, Succeeded, Failed, DeadLetter, Conflict }

public sealed record AdapterCapabilities(
    bool Customers,
    bool DeviceInventory,
    bool Reservations,
    bool SessionControl,
    bool PowerControl,
    bool LiveEvents);

public sealed record AdapterHealth(
    bool Ready,
    string Status,
    string? VendorVersion = null,
    string? ApiVersion = null,
    string? Detail = null);

public sealed record VendorDevice(
    string ExternalId,
    string Name,
    string DeviceType,
    DeviceState State,
    string? ActiveCustomer = null,
    DateTimeOffset? SessionStartedAt = null,
    IReadOnlyDictionary<string, string>? Metadata = null);

public sealed record CustomerIdentity(
    string PgcUserId,
    string ExternalUsername,
    string DisplayName,
    string? Phone = null,
    string? Email = null);

public sealed record SessionRequest(
    string ReservationId,
    string ExternalDeviceId,
    CustomerIdentity Customer,
    DateTimeOffset StartsAt,
    TimeSpan Duration,
    string? ControllerId = null);

public sealed record AdapterResult(
    bool Success,
    string Code,
    string Message,
    string? ExternalReference = null,
    JsonElement? Data = null)
{
    public static AdapterResult Ok(string code = "ok", string message = "OK", string? reference = null) => new(true, code, message, reference);
    public static AdapterResult Fail(string code, string message) => new(false, code, message);
}

public sealed record ConnectorCommand(
    string Id,
    string IdempotencyKey,
    CommandKind Kind,
    string GamenetId,
    string ReservationId,
    DateTimeOffset CreatedAt,
    DateTimeOffset? NotBefore,
    DateTimeOffset? ExpiresAt,
    JsonElement Payload);

public sealed record CommandExecutionResult(
    string CommandId,
    CommandState State,
    string Code,
    string Message,
    DateTimeOffset ExecutedAt,
    string? ExternalReference = null,
    JsonElement? Data = null);

public sealed record DeviceMapping(
    string PgcDeviceId,
    int PgcDeviceIndex,
    string ExternalDeviceId,
    string ExternalDeviceName,
    string DeviceType,
    DateTimeOffset UpdatedAt);

public sealed record PairRequest(string PairCode, string ConnectorName, string MachineFingerprint, string PublicKeyPem, string Version);
public sealed record PairResponse(string ConnectorId, string GamenetId, string GamenetName, string ApiBaseUrl, DateTimeOffset PairedAt);

public sealed class ConnectorSettings
{
    public Uri PgcBaseUrl { get; set; } = new("https://pgc.ir");
    public string ConnectorId { get; set; } = string.Empty;
    public string GamenetId { get; set; } = string.Empty;
    public string GamenetName { get; set; } = string.Empty;
    public string PrivateKeyPem { get; set; } = string.Empty;
    public VendorKind Vendor { get; set; } = VendorKind.Simulator;
    public Uri VendorBaseUrl { get; set; } = new("http://127.0.0.1:7833");
    public string VendorApiToken { get; set; } = string.Empty;
    public string VendorOptionsJson { get; set; } = "{}";
    public int PollSeconds { get; set; } = 10;
    public int SnapshotSeconds { get; set; } = 30;
    public bool AutoStartSessions { get; set; }
    public bool AutoStopSessions { get; set; }
    public bool IsPaired => !string.IsNullOrWhiteSpace(ConnectorId) && !string.IsNullOrWhiteSpace(PrivateKeyPem);
}
