using System.Text.Json;

namespace PGC.Connector.Core;

public sealed class CommandExecutor(IGamingCenterAdapter adapter, IOutboxStore store)
{
    public async Task<CommandExecutionResult> ExecuteAsync(ConnectorCommand command, CancellationToken cancellationToken)
    {
        if (await store.IsProcessedAsync(command.IdempotencyKey, cancellationToken))
            return Result(command, CommandState.Succeeded, "already-processed", "این فرمان قبلاً اجرا شده است.");

        var now = DateTimeOffset.UtcNow;
        if (command.NotBefore is { } notBefore && now < notBefore)
            return Result(command, CommandState.Pending, "not-before", "زمان اجرای فرمان هنوز نرسیده است.");
        if (command.ExpiresAt is { } expiresAt && now > expiresAt)
            return Result(command, CommandState.DeadLetter, "expired", "مهلت اجرای فرمان تمام شده است.");

        try
        {
            var payload = command.Payload;
            var customerPayload = Object(payload, "customer") ?? payload;
            var externalDeviceId = Optional(payload, "externalDeviceId") ?? string.Empty;
            var stableReservation = command.ReservationId.Replace("-", "");
            var externalUsername = Optional(customerPayload, "externalUsername") ?? $"pgc_{stableReservation[..Math.Min(20, stableReservation.Length)]}";
            var customer = new CustomerIdentity(
                Optional(customerPayload, "pgcUserId") ?? "guest",
                externalUsername,
                Optional(customerPayload, "displayName") ?? "PGC Guest",
                Optional(customerPayload, "phone"),
                Optional(customerPayload, "email"));
            var session = new SessionRequest(
                command.ReservationId,
                externalDeviceId,
                customer,
                OptionalDate(payload, "startsAt") ?? now,
                TimeSpan.FromMinutes(OptionalInt(payload, "durationMinutes") ?? 60),
                Optional(payload, "controllerId"));

            AdapterResult adapterResult = command.Kind switch
            {
                CommandKind.EnsureCustomer => await adapter.EnsureCustomerAsync(customer, cancellationToken),
                CommandKind.ReserveDevice => await adapter.ReserveAsync(RequireDevice(session), cancellationToken),
                CommandKind.CancelReservation => await adapter.CancelReservationAsync(Optional(payload, "externalReference") ?? command.ReservationId, cancellationToken),
                CommandKind.StartSession => await adapter.StartSessionAsync(RequireDevice(session), cancellationToken),
                CommandKind.StopSession => await adapter.StopSessionAsync(externalUsername, cancellationToken),
                CommandKind.PowerOn => await adapter.PowerAsync(Required(payload, "externalDeviceId"), true, cancellationToken),
                CommandKind.PowerOff => await adapter.PowerAsync(Required(payload, "externalDeviceId"), false, cancellationToken),
                CommandKind.RefreshInventory => AdapterResult.Ok("refresh-requested", "به‌روزرسانی دستگاه‌ها در صف قرار گرفت."),
                _ => AdapterResult.Fail("unsupported-command", "نوع فرمان پشتیبانی نمی‌شود.")
            };
            return new CommandExecutionResult(command.Id, adapterResult.Success ? CommandState.Succeeded : CommandState.Failed,
                adapterResult.Code, adapterResult.Message, DateTimeOffset.UtcNow, adapterResult.ExternalReference, adapterResult.Data);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception error)
        {
            return Result(command, CommandState.Failed, "adapter-error", error.Message);
        }
    }

    private static CommandExecutionResult Result(ConnectorCommand command, CommandState state, string code, string message) =>
        new(command.Id, state, code, message, DateTimeOffset.UtcNow);

    private static SessionRequest RequireDevice(SessionRequest request) => string.IsNullOrWhiteSpace(request.ExternalDeviceId)
        ? throw new InvalidOperationException("Missing payload field: externalDeviceId")
        : request;

    private static string Required(JsonElement element, string name) =>
        Optional(element, name) ?? throw new InvalidOperationException($"Missing payload field: {name}");

    private static string? Optional(JsonElement element, string name) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() : null;

    private static JsonElement? Object(JsonElement element, string name) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.Object
            ? value : null;

    private static int? OptionalInt(JsonElement element, string name) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(name, out var value) && value.TryGetInt32(out var number) ? number : null;

    private static DateTimeOffset? OptionalDate(JsonElement element, string name) =>
        DateTimeOffset.TryParse(Optional(element, name), out var value) ? value : null;
}
