namespace PGC.Connector.Core;

public interface IGamingCenterAdapter : IAsyncDisposable
{
    VendorKind Kind { get; }
    string DisplayName { get; }
    AdapterCapabilities Capabilities { get; }
    Task<AdapterHealth> ProbeAsync(CancellationToken cancellationToken);
    Task<IReadOnlyList<VendorDevice>> GetDevicesAsync(CancellationToken cancellationToken);
    Task<AdapterResult> EnsureCustomerAsync(CustomerIdentity customer, CancellationToken cancellationToken);
    Task<AdapterResult> ReserveAsync(SessionRequest request, CancellationToken cancellationToken);
    Task<AdapterResult> CancelReservationAsync(string externalReference, CancellationToken cancellationToken);
    Task<AdapterResult> StartSessionAsync(SessionRequest request, CancellationToken cancellationToken);
    Task<AdapterResult> StopSessionAsync(string externalUsername, CancellationToken cancellationToken);
    Task<AdapterResult> PowerAsync(string externalDeviceId, bool on, CancellationToken cancellationToken);
}

public interface IOutboxStore
{
    Task InitializeAsync(CancellationToken cancellationToken);
    Task<bool> IsProcessedAsync(string idempotencyKey, CancellationToken cancellationToken);
    Task SaveIncomingAsync(ConnectorCommand command, CancellationToken cancellationToken);
    Task<IReadOnlyList<ConnectorCommand>> GetReadyAsync(int take, CancellationToken cancellationToken);
    Task<CommandExecutionResult> MarkResultAsync(CommandExecutionResult result, string idempotencyKey, CancellationToken cancellationToken);
    Task EnqueueEventAsync(string eventType, object payload, CancellationToken cancellationToken);
    Task<IReadOnlyList<OutboxEvent>> GetPendingEventsAsync(int take, CancellationToken cancellationToken);
    Task MarkEventsSentAsync(IEnumerable<string> ids, CancellationToken cancellationToken);
    Task UpsertMappingsAsync(IEnumerable<DeviceMapping> mappings, CancellationToken cancellationToken);
    Task<IReadOnlyList<DeviceMapping>> GetMappingsAsync(CancellationToken cancellationToken);
    Task<QueueStatistics> GetStatisticsAsync(CancellationToken cancellationToken);
    Task ClearPairingDataAsync(CancellationToken cancellationToken);
}

public sealed record OutboxEvent(string Id, string EventType, string PayloadJson, DateTimeOffset CreatedAt, int Attempts);
public sealed record QueueStatistics(int PendingCommands, int FailedCommands, int PendingEvents, DateTimeOffset? LastSuccessAt);

public interface ISecureSettingsStore
{
    Task<ConnectorSettings> LoadAsync(CancellationToken cancellationToken);
    Task SaveAsync(ConnectorSettings settings, CancellationToken cancellationToken);
    Task ForgetAsync(CancellationToken cancellationToken);
}
