using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using PGC.Connector.Core;

namespace PGC.Connector.Desktop;

public sealed class LocalConnectorClient
{
    private readonly HttpClient _http = new() { BaseAddress = new Uri("http://127.0.0.1:47831"), Timeout = TimeSpan.FromSeconds(15) };
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public LocalConnectorClient()
    {
        var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "PGC", "Connector", "local-admin-token.txt");
        if (!File.Exists(path)) throw new InvalidOperationException("سرویس PGC Connector نصب یا اجرا نشده است.");
        _http.DefaultRequestHeaders.Add("X-PGC-Local-Token", File.ReadAllText(path).Trim());
    }

    public async Task<JsonDocument> StatusAsync(CancellationToken ct) => await GetJsonAsync("/local/status", ct);
    public async Task<JsonDocument> ConfigAsync(CancellationToken ct) => await GetJsonAsync("/local/config", ct);
    public async Task<IReadOnlyList<VendorDevice>> DevicesAsync(CancellationToken ct) => await _http.GetFromJsonAsync<List<VendorDevice>>("/local/devices", Json, ct) ?? [];
    public async Task<IReadOnlyList<string>> LogsAsync(CancellationToken ct) => await _http.GetFromJsonAsync<List<string>>("/local/logs?take=150", Json, ct) ?? [];

    public async Task PairAsync(Uri url, string code, string name, CancellationToken ct)
    {
        using var response = await _http.PostAsJsonAsync("/local/pair", new { pgcBaseUrl = url, pairCode = code, connectorName = name }, Json, ct);
        await EnsureAsync(response, ct);
    }

    public async Task SaveSettingsAsync(object settings, CancellationToken ct)
    {
        using var response = await _http.PostAsJsonAsync("/local/settings", settings, Json, ct);
        await EnsureAsync(response, ct);
    }

    public async Task ForgetAsync(CancellationToken ct)
    {
        using var response = await _http.PostAsJsonAsync("/local/forget", new { }, Json, ct);
        await EnsureAsync(response, ct);
    }

    private async Task<JsonDocument> GetJsonAsync(string path, CancellationToken ct)
    {
        using var response = await _http.GetAsync(path, ct);
        await EnsureAsync(response, ct);
        return JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
    }

    private static async Task EnsureAsync(HttpResponseMessage response, CancellationToken ct)
    {
        if (response.IsSuccessStatusCode) return;
        var body = await response.Content.ReadAsStringAsync(ct);
        throw new InvalidOperationException($"سرویس Connector خطا داد (HTTP {(int)response.StatusCode}): {body[..Math.Min(400, body.Length)]}");
    }
}
