using System.Windows;
using Forms = System.Windows.Forms;

namespace PGC.Connector.Desktop;

public partial class App : System.Windows.Application
{
    private Forms.NotifyIcon? _tray;
    private MainWindow? _window;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _window = new MainWindow();
        _window.Show();
        var processPath = System.Environment.ProcessPath;
        var trayIcon = !string.IsNullOrWhiteSpace(processPath)
            ? System.Drawing.Icon.ExtractAssociatedIcon(processPath)
            : null;
        _tray = new Forms.NotifyIcon
        {
            Icon = trayIcon ?? System.Drawing.SystemIcons.Application,
            Text = "PGC Connector",
            Visible = true,
            ContextMenuStrip = new Forms.ContextMenuStrip()
        };
        _tray.ContextMenuStrip.Items.Add("باز کردن", null, (_, _) => ShowWindow());
        _tray.ContextMenuStrip.Items.Add("خروج از رابط", null, (_, _) => ExitUi());
        _tray.DoubleClick += (_, _) => ShowWindow();
    }

    private void ShowWindow()
    {
        if (_window is null) return;
        _window.Show();
        _window.WindowState = WindowState.Normal;
        _window.Activate();
    }

    private void ExitUi()
    {
        _tray?.Dispose();
        Shutdown();
    }
}
