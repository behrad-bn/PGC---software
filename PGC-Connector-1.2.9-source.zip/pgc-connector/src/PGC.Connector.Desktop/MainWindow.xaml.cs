using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PGC.Connector.Core;

namespace PGC.Connector.Desktop;

public partial class MainWindow : Window
{
    private LocalConnectorClient? _client;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(5) };
    private Dictionary<string, FrameworkElement> _pages = null!;
    private Dictionary<string, (string Title, string Subtitle)> _pageHeadings = null!;
    private Button[] _navigationButtons = null!;
    private bool _menuOpen;

    public MainWindow()
    {
        InitializeComponent();
        _pages = new Dictionary<string, FrameworkElement>(StringComparer.OrdinalIgnoreCase)
        {
            ["home"] = HomePage,
            ["pairing"] = PairingPage,
            ["vendor"] = VendorPage,
            ["devices"] = DevicesPage,
            ["logs"] = LogsPage,
            ["tutorial"] = TutorialPage
        };
        _pageHeadings = new Dictionary<string, (string Title, string Subtitle)>(StringComparer.OrdinalIgnoreCase)
        {
            ["home"] = ("خانه", "پل امن میان PGC و سیستم مدیریت گیم‌نت"),
            ["pairing"] = ("اتصال به PGC", "Pairing یک‌بارمصرف و مدیریت اتصال این سیستم"),
            ["vendor"] = ("نرم‌افزار مدیریت", "تنظیم Adapter برای Smartlaunch و نرم‌افزارهای دیگر"),
            ["devices"] = ("دستگاه‌ها", "مشاهده وضعیت سیستم‌های گیم‌نت"),
            ["logs"] = ("گزارش‌ها", "رخدادهای عملیاتی و امنیتی Connector"),
            ["tutorial"] = ("آموزش تصویری", "راه‌اندازی اتصال در سه مرحله")
        };
        _navigationButtons =
        [
            HomeNavButton,
            PairingNavButton,
            VendorNavButton,
            DevicesNavButton,
            LogsNavButton,
            TutorialNavButton
        ];

        VendorBox.SelectedIndex = 0;
        FooterVersion.Text = $"PGC Connector {typeof(MainWindow).Assembly.GetName().Version?.ToString(3) ?? "—"}";
        SetPage("home");
        Loaded += async (_, _) => await InitializeAsync();
        Closing += (_, args) => { args.Cancel = true; Hide(); };
        _timer.Tick += async (_, _) => await RefreshAsync(false);
    }

    protected override void OnPreviewKeyDown(KeyEventArgs e)
    {
        if (e.Key == Key.Escape && _menuOpen)
        {
            CloseMenu();
            e.Handled = true;
        }
        base.OnPreviewKeyDown(e);
    }

    private async Task InitializeAsync()
    {
        try
        {
            _client = new LocalConnectorClient();
            await LoadConfigAsync();
            await RefreshAsync(true);
            _timer.Start();
        }
        catch (Exception error)
        {
            HeaderStatus.Text = "سرویس در دسترس نیست";
            HeaderDot.Fill = Brushes.Red;
            ShowError(error);
        }
    }

    private async Task RefreshAsync(bool showErrors)
    {
        if (_client is null) return;
        try
        {
            using var doc = await _client.StatusAsync(CancellationToken.None);
            var root = doc.RootElement;
            var paired = root.GetProperty("paired").GetBoolean();
            var adapterReady = root.GetProperty("adapter").GetProperty("ready").GetBoolean();
            HeaderStatus.Text = paired && adapterReady ? "همه‌چیز آماده است" : paired ? "Vendor نیازمند بررسی" : "اتصال به PGC انجام نشده";
            HeaderDot.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(paired && adapterReady ? "#22C55E" : paired ? "#F59E0B" : "#71717A"));
            CloudStatus.Text = paired ? "Pair شده" : "قطع";
            AdapterStatus.Text = root.GetProperty("adapter").GetProperty("status").GetString() ?? "—";
            VenueName.Text = root.TryGetProperty("gamenetName", out var venue) && !string.IsNullOrWhiteSpace(venue.GetString()) ? venue.GetString()! : "هنوز Pair نشده";
            ConnectorVersion.Text = root.GetProperty("version").GetString() ?? "—";
            LastSync.Text = root.TryGetProperty("lastCloudSuccessAt", out var sync) && sync.ValueKind == JsonValueKind.String
                ? DateTimeOffset.Parse(sync.GetString()!, CultureInfo.InvariantCulture).ToLocalTime().ToString("yyyy/MM/dd HH:mm:ss", CultureInfo.GetCultureInfo("fa-IR"))
                : "هنوز انجام نشده";
            var queue = root.GetProperty("queue");
            PendingCommands.Text = queue.GetProperty("pendingCommands").GetInt32().ToString("N0", CultureInfo.GetCultureInfo("fa-IR"));
            PendingEvents.Text = queue.GetProperty("pendingEvents").GetInt32().ToString("N0", CultureInfo.GetCultureInfo("fa-IR"));
            PairingState.Text = paired ? $"متصل به {VenueName.Text}" : "Pair نشده";
        }
        catch (Exception error)
        {
            HeaderStatus.Text = "سرویس در دسترس نیست";
            HeaderDot.Fill = Brushes.Red;
            if (showErrors) ShowError(error);
        }
    }

    private async Task LoadConfigAsync()
    {
        if (_client is null) return;
        using var doc = await _client.ConfigAsync(CancellationToken.None);
        var root = doc.RootElement;
        PgcUrlBox.Text = root.GetProperty("pgcBaseUrl").GetString() ?? "https://pgc.ir";
        VendorUrlBox.Text = root.GetProperty("vendorBaseUrl").GetString() ?? "http://127.0.0.1:7833";
        VendorOptionsBox.Text = root.GetProperty("vendorOptionsJson").GetString() ?? "{}";
        AutoStartBox.IsChecked = root.GetProperty("autoStartSessions").GetBoolean();
        AutoStopBox.IsChecked = root.GetProperty("autoStopSessions").GetBoolean();
        var vendor = root.GetProperty("vendor").GetString();
        VendorBox.SelectedIndex = VendorBox.Items.Cast<ComboBoxItem>()
            .Select((item, index) => (item, index))
            .FirstOrDefault(pair => string.Equals(pair.item.Tag?.ToString(), vendor, StringComparison.OrdinalIgnoreCase))
            .index;
    }

    private void MenuToggle_Click(object sender, RoutedEventArgs e)
    {
        if (_menuOpen) CloseMenu();
        else OpenMenu();
    }

    private void OpenMenu()
    {
        _menuOpen = true;
        MenuTransform.BeginAnimation(System.Windows.Media.TranslateTransform.XProperty, null);
        MenuTransform.X = MenuPanel.Width;
        MenuPanel.Visibility = Visibility.Visible;
        MenuScrim.Visibility = Visibility.Visible;
        MenuTransform.BeginAnimation(System.Windows.Media.TranslateTransform.XProperty,
            new DoubleAnimation(MenuPanel.Width, 0, TimeSpan.FromMilliseconds(220)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        MenuScrim.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180)));
    }

    private void CloseMenu()
    {
        if (!_menuOpen) return;
        _menuOpen = false;
        var slide = new DoubleAnimation(0, MenuPanel.Width, TimeSpan.FromMilliseconds(180)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
        slide.Completed += (_, _) =>
        {
            if (_menuOpen) return;
            MenuPanel.Visibility = Visibility.Collapsed;
            MenuScrim.Visibility = Visibility.Collapsed;
        };
        MenuTransform.BeginAnimation(System.Windows.Media.TranslateTransform.XProperty, slide);
        MenuScrim.BeginAnimation(OpacityProperty, new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(160)));
    }

    private void CloseMenu_Click(object sender, RoutedEventArgs e) => CloseMenu();
    private void MenuScrim_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) => CloseMenu();

    private void NavigationButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string key }) return;
        SetPage(key);
        CloseMenu();
    }

    private void OpenTutorial_Click(object sender, RoutedEventArgs e) => SetPage("tutorial");

    private void SetPage(string key)
    {
        if (!_pages.TryGetValue(key, out var selectedPage)) return;
        foreach (var page in _pages.Values) page.Visibility = Visibility.Collapsed;
        selectedPage.Visibility = Visibility.Visible;
        selectedPage.BeginAnimation(OpacityProperty,
            new DoubleAnimation(0.72, 1, TimeSpan.FromMilliseconds(150)) { EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut } });
        var heading = _pageHeadings[key];
        PageTitle.Text = heading.Title;
        PageSubtitle.Text = heading.Subtitle;

        foreach (var button in _navigationButtons)
        {
            var selected = string.Equals(button.Tag?.ToString(), key, StringComparison.OrdinalIgnoreCase);
            button.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(selected ? "#E31B2B" : "#252A32"));
            button.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(selected ? "#FF5965" : "#4A515D"));
            button.Foreground = Brushes.White;
        }
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync(true);

    private async void Pair_Click(object sender, RoutedEventArgs e)
    {
        if (_client is null) return;
        try
        {
            if (!Uri.TryCreate(PgcUrlBox.Text.Trim(), UriKind.Absolute, out var uri)) throw new InvalidOperationException("آدرس PGC معتبر نیست.");
            if (PairCodeBox.Text.Trim().Length < 6) throw new InvalidOperationException("کد Pairing معتبر نیست.");
            await _client.PairAsync(uri, PairCodeBox.Text.Trim(), ConnectorNameBox.Text.Trim(), CancellationToken.None);
            PairCodeBox.Clear();
            await RefreshAsync(true);
            MessageBox.Show("اتصال امن با موفقیت انجام شد.", "PGC Connector", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception error) { ShowError(error); }
    }

    private async void Forget_Click(object sender, RoutedEventArgs e)
    {
        if (_client is null || MessageBox.Show("اتصال این سیستم با PGC باطل شود؟", "تأیید Forget", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        try
        {
            await _client.ForgetAsync(CancellationToken.None);
            await RefreshAsync(true);
        }
        catch (Exception error) { ShowError(error); }
    }

    private async void SaveAdapter_Click(object sender, RoutedEventArgs e)
    {
        if (_client is null) return;
        try
        {
            using var _ = JsonDocument.Parse(VendorOptionsBox.Text);
            if (!Uri.TryCreate(VendorUrlBox.Text.Trim(), UriKind.Absolute, out var vendorUrl)) throw new InvalidOperationException("Base URL معتبر نیست.");
            var item = (ComboBoxItem)VendorBox.SelectedItem;
            if (!Enum.TryParse<VendorKind>(item.Tag?.ToString(), out var vendor)) throw new InvalidOperationException("Vendor معتبر نیست.");
            await _client.SaveSettingsAsync(new
            {
                vendor,
                vendorBaseUrl = vendorUrl,
                vendorApiToken = string.IsNullOrWhiteSpace(VendorTokenBox.Password) ? null : VendorTokenBox.Password,
                vendorOptionsJson = VendorOptionsBox.Text,
                autoStartSessions = AutoStartBox.IsChecked == true,
                autoStopSessions = AutoStopBox.IsChecked == true,
                pollSeconds = 10
            }, CancellationToken.None);
            VendorTokenBox.Clear();
            await RefreshAsync(true);
            MessageBox.Show("تنظیمات ذخیره شد. وضعیت Adapter در خانه نمایش داده می‌شود.", "PGC Connector", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception error) { ShowError(error); }
    }

    private async void LoadDevices_Click(object sender, RoutedEventArgs e)
    {
        if (_client is null) return;
        try
        {
            var devices = await _client.DevicesAsync(CancellationToken.None);
            DevicesGrid.ItemsSource = devices;
            DevicesHint.Text = $"{devices.Count:N0} دستگاه دریافت شد";
        }
        catch (Exception error) { ShowError(error); }
    }

    private async void LoadLogs_Click(object sender, RoutedEventArgs e)
    {
        if (_client is null) return;
        try { LogsList.ItemsSource = await _client.LogsAsync(CancellationToken.None); }
        catch (Exception error) { ShowError(error); }
    }

    private static void ShowError(Exception error) =>
        MessageBox.Show(error.Message, "خطای PGC Connector", MessageBoxButton.OK, MessageBoxImage.Error);
}
