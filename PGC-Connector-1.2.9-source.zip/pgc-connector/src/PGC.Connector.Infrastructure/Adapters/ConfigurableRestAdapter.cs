using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using PGC.Connector.Core;

namespace PGC.Connector.Infrastructure.Adapters;

public sealed class ConfigurableRestAdapter : IGamingCenterAdapter
{
    private readonly HttpClient _http;
    private readonly RestBridgeOptions _options;

    public ConfigurableRestAdapter(HttpClient httpClient, ConnectorSettings settings, VendorKind kind, string displayName)
    {
        Kind = kind;
        DisplayName = displayName;
        _options = JsonSerializer.Deserialize<RestBridgeOptions>(settings.VendorOptionsJson, Json) ?? new RestBridgeOptions();
        if (_options.Enabled)
        {
            NetworkSafety.RequireLocalOrPrivate(settings.VendorBaseUrl);
            if (settings.VendorBaseUrl.Scheme != Uri.UriSchemeHttps && !settings.VendorBaseUrl.IsLoopback)
                throw new InvalidOperationException("اتصال HTTP فقط به همین دستگاه مجاز است؛ برای شبکهٔ محلی HTTPS لازم است.");
            if (kind == VendorKind.GenericSdkBridge && string.IsNullOrWhiteSpace(settings.VendorApiToken))
                throw new InvalidOperationException("SDK Bridge باید کلید دسترسی اختصاصی داشته باشد.");
        }
        _http = httpClient;
        _http.BaseAddress = settings.VendorBaseUrl;
        _http.Timeout = TimeSpan.FromSeconds(15);
        if (_options.TokenScheme is not ("Bearer" or "Token"))
            throw new InvalidOperationException("فقط TokenScheme مجاز Bearer یا Token است.");
        if (!string.IsNullOrWhiteSpace(settings.VendorApiToken))
            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(_options.TokenScheme, settings.VendorApiToken);
    }

    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };
    public VendorKind Kind { get; }
    public string DisplayName { get; }
    public AdapterCapabilities Capabilities => new(Route("ensureCustomer") is not null, Route("devices") is not null,
        Route("reserve") is not null, Route("startSession") is not null && Route("stopSession") is not null,
        Route("power") is not null, false);

    public async Task<AdapterHealth> ProbeAsync(CancellationToken cancellationToken)
    {
        if (!_options.Enabled) return new AdapterHealth(false, "نیازمند مستندات یا API Key", Detail: "Adapter آماده است اما Endpoint واقعی Vendor هنوز تعریف نشده است.");
        var route = Route("health");
        if (route is null) return new AdapterHealth(false, "پیکربندی ناقص", Detail: "Route health تعریف نشده است.");
        try
        {
            using var response = await SendAsync(route, null, cancellationToken);
            return new AdapterHealth(response.IsSuccessStatusCode, response.IsSuccessStatusCode ? "متصل" : "خطای Vendor", Detail: $"HTTP {(int)response.StatusCode}");
        }
        catch (Exception error) when (error is HttpRequestException or TaskCanceledException)
        {
            return new AdapterHealth(false, "قطع", Detail: error.Message);
        }
    }

    public async Task<IReadOnlyList<VendorDevice>> GetDevicesAsync(CancellationToken cancellationToken)
    {
        var route = RequireRoute("devices");
        using var response = await SendAsync(route, null, cancellationToken);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<List<VendorDevice>>(Json, cancellationToken) ?? [];
    }

    public Task<AdapterResult> EnsureCustomerAsync(CustomerIdentity customer, CancellationToken cancellationToken) => ExecuteAsync("ensureCustomer", customer, cancellationToken);
    public Task<AdapterResult> ReserveAsync(SessionRequest request, CancellationToken cancellationToken) => ExecuteAsync("reserve", request, cancellationToken);
    public Task<AdapterResult> CancelReservationAsync(string externalReference, CancellationToken cancellationToken) => ExecuteAsync("cancelReservation", new { externalReference }, cancellationToken);
    public Task<AdapterResult> StartSessionAsync(SessionRequest request, CancellationToken cancellationToken) => ExecuteAsync("startSession", request, cancellationToken);
    public Task<AdapterResult> StopSessionAsync(string externalUsername, CancellationToken cancellationToken) => ExecuteAsync("stopSession", new { externalUsername }, cancellationToken);
    public Task<AdapterResult> PowerAsync(string externalDeviceId, bool on, CancellationToken cancellationToken) => ExecuteAsync("power", new { externalDeviceId, on }, cancellationToken);

    private async Task<AdapterResult> ExecuteAsync(string name, object payload, CancellationToken cancellationToken)
    {
        if (!_options.Enabled) return AdapterResult.Fail("adapter-not-configured", $"Adapter {DisplayName} هنوز Endpoint تأییدشده ندارد.");
        var route = Route(name);
        if (route is null) return AdapterResult.Fail("route-not-configured", $"Route {name} تعریف نشده است.");
        using var response = await SendAsync(route, payload, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        // Vendor error bodies are untrusted and can echo credentials or customer data.
        if (!response.IsSuccessStatusCode) return AdapterResult.Fail("vendor-http-error", $"HTTP {(int)response.StatusCode}");
        try
        {
            var parsed = JsonSerializer.Deserialize<AdapterResult>(body, Json);
            return parsed ?? AdapterResult.Fail("vendor-invalid-response", "پاسخ Vendor تهی است.");
        }
        catch (JsonException) { return AdapterResult.Fail("vendor-invalid-response", "پاسخ Vendor ساختار مورد انتظار را ندارد."); }
    }

    private Task<HttpResponseMessage> SendAsync(RestRoute route, object? body, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(route.Path) || !route.Path.StartsWith("/", StringComparison.Ordinal)
            || route.Path.StartsWith("//", StringComparison.Ordinal) || route.Path.Contains('\\')
            || route.Path.Contains("..", StringComparison.Ordinal) || route.Path.Contains('#')
            || route.Path.Contains('%') || route.Path.Any(char.IsControl))
            throw new InvalidOperationException("مسیر Adapter نامعتبر است.");
        var method = route.Method.ToUpperInvariant() switch
        {
            "GET" => HttpMethod.Get,
            "POST" => HttpMethod.Post,
            "PUT" => HttpMethod.Put,
            "DELETE" => HttpMethod.Delete,
            _ => throw new InvalidOperationException("روش HTTP غیرمجاز است.")
        };
        if (body is not null && method == HttpMethod.Get) throw new InvalidOperationException("ارسال داده با GET مجاز نیست.");
        var target = new Uri(_http.BaseAddress!, route.Path);
        if (!string.Equals(target.Authority, _http.BaseAddress!.Authority, StringComparison.OrdinalIgnoreCase)
            || target.Scheme != _http.BaseAddress.Scheme)
            throw new InvalidOperationException("مسیر Vendor از میزبان تنظیم‌شده خارج می‌شود.");
        var request = new HttpRequestMessage(method, target);
        if (body is not null) request.Content = JsonContent.Create(body, options: Json);
        return _http.SendAsync(request, cancellationToken);
    }

    private RestRoute? Route(string name) => _options.Routes.TryGetValue(name, out var route) ? route : null;
    private RestRoute RequireRoute(string name) => Route(name) ?? throw new InvalidOperationException($"Route {name} تعریف نشده است.");
    public ValueTask DisposeAsync() => ValueTask.CompletedTask;

    private sealed class RestBridgeOptions
    {
        public bool Enabled { get; set; }
        public string TokenScheme { get; set; } = "Bearer";
        public Dictionary<string, RestRoute> Routes { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    }

    private sealed class RestRoute
    {
        public string Method { get; set; } = "GET";
        public string Path { get; set; } = "/";
    }
}
