using PGC.Connector.Core;

namespace PGC.Connector.Infrastructure.Adapters;

public sealed class SimulatorAdapter : IGamingCenterAdapter
{
    private readonly Dictionary<string, VendorDevice> _devices = Enumerable.Range(1, 12)
        .ToDictionary(index => $"SIM-{index:00}", index => new VendorDevice($"SIM-{index:00}", $"PC {index:00}", "PC", DeviceState.Available));

    public VendorKind Kind => VendorKind.Simulator;
    public string DisplayName => "شبیه‌ساز داخلی PGC";
    public AdapterCapabilities Capabilities => new(true, true, true, true, true, true);
    public Task<AdapterHealth> ProbeAsync(CancellationToken cancellationToken) => Task.FromResult(new AdapterHealth(true, "آماده", "1.0", "1.0"));
    public Task<IReadOnlyList<VendorDevice>> GetDevicesAsync(CancellationToken cancellationToken) => Task.FromResult<IReadOnlyList<VendorDevice>>(_devices.Values.ToArray());
    public Task<AdapterResult> EnsureCustomerAsync(CustomerIdentity customer, CancellationToken cancellationToken) => Task.FromResult(AdapterResult.Ok("customer-ready", "کاربر شبیه‌سازی شد.", customer.ExternalUsername));
    public Task<AdapterResult> ReserveAsync(SessionRequest request, CancellationToken cancellationToken) => Task.FromResult(SetState(request.ExternalDeviceId, DeviceState.Reserved, request.Customer.ExternalUsername));
    public Task<AdapterResult> CancelReservationAsync(string externalReference, CancellationToken cancellationToken) => Task.FromResult(AdapterResult.Ok("reservation-cancelled", "رزرو شبیه‌سازی‌شده لغو شد.", externalReference));
    public Task<AdapterResult> StartSessionAsync(SessionRequest request, CancellationToken cancellationToken) => Task.FromResult(SetState(request.ExternalDeviceId, DeviceState.InUse, request.Customer.ExternalUsername));
    public Task<AdapterResult> StopSessionAsync(string externalUsername, CancellationToken cancellationToken)
    {
        var item = _devices.FirstOrDefault(pair => pair.Value.ActiveCustomer == externalUsername);
        return Task.FromResult(string.IsNullOrWhiteSpace(item.Key) ? AdapterResult.Ok("already-stopped", "نشست فعالی وجود نداشت.") : SetState(item.Key, DeviceState.Available, null));
    }
    public Task<AdapterResult> PowerAsync(string externalDeviceId, bool on, CancellationToken cancellationToken) => Task.FromResult(SetState(externalDeviceId, on ? DeviceState.Available : DeviceState.Offline, null));
    private AdapterResult SetState(string id, DeviceState state, string? customer)
    {
        if (!_devices.TryGetValue(id, out var device)) return AdapterResult.Fail("device-not-found", "دستگاه پیدا نشد.");
        _devices[id] = device with { State = state, ActiveCustomer = customer, SessionStartedAt = state == DeviceState.InUse ? DateTimeOffset.UtcNow : null };
        return AdapterResult.Ok("simulated", "فرمان با موفقیت در شبیه‌ساز اجرا شد.", id);
    }
    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
