using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using PGC.Connector.Core;

namespace PGC.Connector.Infrastructure.Adapters;

public sealed class SmartlaunchAdapter : IGamingCenterAdapter
{
    private readonly HttpClient _http;
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true };

    public SmartlaunchAdapter(HttpClient httpClient, Uri baseUrl)
    {
        NetworkSafety.RequireLocalOrPrivate(baseUrl);
        _http = httpClient;
        _http.BaseAddress = baseUrl;
        _http.Timeout = TimeSpan.FromSeconds(10);
    }

    public VendorKind Kind => VendorKind.Smartlaunch;
    public string DisplayName => "Smartlaunch REST API";
    public AdapterCapabilities Capabilities => new(true, true, false, true, true, false);

    public async Task<AdapterHealth> ProbeAsync(CancellationToken cancellationToken)
    {
        try
        {
            var api = await _http.GetStringAsync("/restapiversion", cancellationToken);
            var version = await _http.GetStringAsync("/smartlaunchversion", cancellationToken);
            return new AdapterHealth(true, "متصل", version.Trim(), api.Trim());
        }
        catch (Exception error) when (error is HttpRequestException or TaskCanceledException)
        {
            return new AdapterHealth(false, "قطع", Detail: error.Message);
        }
    }

    public async Task<IReadOnlyList<VendorDevice>> GetDevicesAsync(CancellationToken cancellationToken)
    {
        using var response = await _http.GetAsync("/computers", cancellationToken);
        response.EnsureSuccessStatusCode();
        var raw = await response.Content.ReadAsStringAsync(cancellationToken);
        using var document = JsonDocument.Parse(raw);
        var array = FindArray(document.RootElement);
        var items = array is { } value
            ? JsonSerializer.Deserialize<List<SmartlaunchComputer>>(value.GetRawText(), Json) ?? []
            : [];
        return items.Select(item => new VendorDevice(
            item.ComputerID ?? item.Name ?? item.ComputerName ?? throw new InvalidOperationException("Smartlaunch computer has no id"),
            item.Name ?? item.ComputerName ?? item.ComputerID ?? "Unknown",
            string.Equals(item.ConsoleType, "Disabled", StringComparison.OrdinalIgnoreCase) ? "PC" : "Console",
            Powered(item) ? string.IsNullOrWhiteSpace(item.ActiveUserName ?? item.CurrentUserName) ? DeviceState.Available : DeviceState.InUse : DeviceState.Offline,
            item.ActiveUserName ?? item.CurrentUserName)).ToArray();
    }

    public async Task<AdapterResult> EnsureCustomerAsync(CustomerIdentity customer, CancellationToken cancellationToken)
    {
        using var existing = await _http.GetAsync($"/users/{Uri.EscapeDataString(customer.ExternalUsername)}", cancellationToken);
        if (existing.IsSuccessStatusCode) return AdapterResult.Ok("customer-exists", "کاربر Smartlaunch موجود است.", customer.ExternalUsername);
        if (existing.StatusCode != HttpStatusCode.NotFound) return AdapterResult.Fail("customer-read-failed", $"Smartlaunch HTTP {(int)existing.StatusCode}");
        var body = new { UserCreate = new { UserName = customer.ExternalUsername, UsergroupName = "Members" } };
        using var created = await _http.PostAsJsonAsync("/users", body, Json, cancellationToken);
        return created.IsSuccessStatusCode
            ? AdapterResult.Ok("customer-created", "کاربر Smartlaunch ساخته شد.", customer.ExternalUsername)
            : AdapterResult.Fail("customer-create-failed", $"Smartlaunch HTTP {(int)created.StatusCode}");
    }

    public Task<AdapterResult> ReserveAsync(SessionRequest request, CancellationToken cancellationToken) =>
        Task.FromResult(AdapterResult.Fail("not-supported", "REST API مستند Smartlaunch عملیات Booking مستقل ندارد؛ رزرو در PGC نگهداری می‌شود."));

    public Task<AdapterResult> CancelReservationAsync(string externalReference, CancellationToken cancellationToken) =>
        Task.FromResult(AdapterResult.Ok("pgc-owned", "رزرو متعلق به PGC است و رکورد Vendor برای لغو وجود ندارد.", externalReference));

    public async Task<AdapterResult> StartSessionAsync(SessionRequest request, CancellationToken cancellationToken)
    {
        var customer = await EnsureCustomerAsync(request.Customer, cancellationToken);
        if (!customer.Success) return customer;
        var user = Uri.EscapeDataString(request.Customer.ExternalUsername);
        var device = Uri.EscapeDataString(request.ExternalDeviceId);
        var path = string.IsNullOrWhiteSpace(request.ControllerId)
            ? $"/users/{user}/login?computername={device}"
            : $"/users/{user}/logintoconsole?consolename={device}&controllerid={Uri.EscapeDataString(request.ControllerId)}";
        using var response = await _http.GetAsync(path, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        return response.IsSuccessStatusCode && body.Contains("true", StringComparison.OrdinalIgnoreCase)
            ? AdapterResult.Ok("session-started", "نشست Smartlaunch شروع شد.", request.ExternalDeviceId)
            : AdapterResult.Fail("session-start-failed", $"Smartlaunch پاسخ ناموفق داد: {body[..Math.Min(200, body.Length)]}");
    }

    public async Task<AdapterResult> StopSessionAsync(string externalUsername, CancellationToken cancellationToken)
    {
        using var response = await _http.GetAsync($"/users/{Uri.EscapeDataString(externalUsername)}/logout", cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        return response.IsSuccessStatusCode && body.Contains("true", StringComparison.OrdinalIgnoreCase)
            ? AdapterResult.Ok("session-stopped", "نشست Smartlaunch پایان یافت.", externalUsername)
            : AdapterResult.Fail("session-stop-failed", $"Smartlaunch پاسخ ناموفق داد: {body[..Math.Min(200, body.Length)]}");
    }

    public async Task<AdapterResult> PowerAsync(string externalDeviceId, bool on, CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Put, $"/computers/{Uri.EscapeDataString(externalDeviceId)}/{(on ? "turnon" : "turnoff")}");
        using var response = await _http.SendAsync(request, cancellationToken);
        return response.IsSuccessStatusCode
            ? AdapterResult.Ok(on ? "power-on-requested" : "power-off-requested", "فرمان برق ارسال شد.", externalDeviceId)
            : AdapterResult.Fail("power-command-failed", $"Smartlaunch HTTP {(int)response.StatusCode}");
    }

    public ValueTask DisposeAsync() => ValueTask.CompletedTask;

    private static JsonElement? FindArray(JsonElement root)
    {
        if (root.ValueKind == JsonValueKind.Array) return root;
        if (root.ValueKind != JsonValueKind.Object) return null;
        foreach (var property in root.EnumerateObject())
        {
            if (property.Value.ValueKind == JsonValueKind.Array) return property.Value;
            if (property.Value.ValueKind == JsonValueKind.Object && FindArray(property.Value) is { } nested) return nested;
        }
        return null;
    }

    private static bool Powered(SmartlaunchComputer item)
    {
        if (item.TurnedOn is { } turnedOn) return turnedOn;
        return !string.Equals(item.State, "Offline", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(item.State, "Off", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(item.State, "TurnedOff", StringComparison.OrdinalIgnoreCase);
    }

    private sealed class SmartlaunchComputer
    {
        public string? ComputerID { get; set; }
        public string? Name { get; set; }
        public string? ComputerName { get; set; }
        public string? ConsoleType { get; set; }
        public bool? TurnedOn { get; set; }
        public string? State { get; set; }
        public string? ActiveUserName { get; set; }
        public string? CurrentUserName { get; set; }
    }
}
