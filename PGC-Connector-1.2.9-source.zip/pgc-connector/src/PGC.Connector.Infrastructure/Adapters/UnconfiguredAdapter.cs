using PGC.Connector.Core;

namespace PGC.Connector.Infrastructure.Adapters;

public sealed class UnconfiguredAdapter : IGamingCenterAdapter
{
    public VendorKind Kind => VendorKind.Simulator;
    public string DisplayName => "اتصال تعریف نشده";
    public AdapterCapabilities Capabilities => new(false, false, false, false, false, false);
    public Task<AdapterHealth> ProbeAsync(CancellationToken ct) => Task.FromResult(new AdapterHealth(false, "اتصال محلی تنظیم نشده است"));
    public Task<IReadOnlyList<VendorDevice>> GetDevicesAsync(CancellationToken ct) => Task.FromResult<IReadOnlyList<VendorDevice>>([]);
    public Task<AdapterResult> EnsureCustomerAsync(CustomerIdentity customer, CancellationToken ct) => Unavailable();
    public Task<AdapterResult> ReserveAsync(SessionRequest request, CancellationToken ct) => Unavailable();
    public Task<AdapterResult> CancelReservationAsync(string reference, CancellationToken ct) => Unavailable();
    public Task<AdapterResult> StartSessionAsync(SessionRequest request, CancellationToken ct) => Unavailable();
    public Task<AdapterResult> StopSessionAsync(string username, CancellationToken ct) => Unavailable();
    public Task<AdapterResult> PowerAsync(string deviceId, bool on, CancellationToken ct) => Unavailable();
    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
    private static Task<AdapterResult> Unavailable() => Task.FromResult(AdapterResult.Fail("adapter-unconfigured", "هیچ اتصال Vendor تأییدشده‌ای تنظیم نشده است."));
}
