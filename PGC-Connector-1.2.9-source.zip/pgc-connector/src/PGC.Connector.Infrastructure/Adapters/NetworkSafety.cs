using System.Net;

namespace PGC.Connector.Infrastructure.Adapters;

public static class NetworkSafety
{
    public static void RequireLocalOrPrivate(Uri endpoint)
    {
        if (!endpoint.IsAbsoluteUri || !string.IsNullOrEmpty(endpoint.UserInfo)
            || !string.IsNullOrEmpty(endpoint.Query) || !string.IsNullOrEmpty(endpoint.Fragment))
            throw new InvalidOperationException("آدرس Vendor نباید کاربر، Query یا Fragment داشته باشد.");
        if (endpoint.Scheme is not ("http" or "https")) throw new InvalidOperationException("فقط HTTP/HTTPS مجاز است.");
        if (endpoint.IsLoopback || endpoint.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase)) return;
        if (!IPAddress.TryParse(endpoint.Host, out var address))
            throw new InvalidOperationException("برای اتصال محلی باید IP خصوصی یا localhost وارد شود؛ نام میزبان ناشناس مجاز نیست.");
        var bytes = address.GetAddressBytes();
        var isPrivate = address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
            (bytes[0] == 10 || bytes[0] == 127 || bytes[0] == 192 && bytes[1] == 168 || bytes[0] == 172 && bytes[1] is >= 16 and <= 31);
        if (!isPrivate) throw new InvalidOperationException("Endpoint محلی باید روی Loopback یا شبکهٔ خصوصی باشد.");
    }
}
