using PGC.Connector.Core;
using PGC.Connector.Infrastructure.Adapters;

namespace PGC.Connector.Infrastructure;

public static class AdapterFactory
{
    public static IGamingCenterAdapter Create(ConnectorSettings settings, HttpClient httpClient) => settings.Vendor switch
    {
        VendorKind.Smartlaunch or VendorKind.GgLeap or VendorKind.LaunchDesk => new UnconfiguredAdapter(),
        VendorKind.GenericRest => new ConfigurableRestAdapter(httpClient, settings, VendorKind.GenericRest, "REST سفارشی"),
        VendorKind.GenericSdkBridge => new ConfigurableRestAdapter(httpClient, settings, VendorKind.GenericSdkBridge, "SDK Bridge محلی"),
        VendorKind.Simulator => new UnconfiguredAdapter(),
        _ => throw new InvalidOperationException("Adapter نامعتبر است.")
    };
}
