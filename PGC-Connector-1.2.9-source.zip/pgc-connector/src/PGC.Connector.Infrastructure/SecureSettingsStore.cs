using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using PGC.Connector.Core;

namespace PGC.Connector.Infrastructure;

public sealed class SecureSettingsStore : ISecureSettingsStore
{
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("PGC.Connector.Settings.v1");
    private readonly string _path;
    private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public SecureSettingsStore(string dataDirectory)
    {
        Directory.CreateDirectory(dataDirectory);
        _path = Path.Combine(dataDirectory, "settings.bin");
    }

    public async Task<ConnectorSettings> LoadAsync(CancellationToken cancellationToken)
    {
        if (!File.Exists(_path)) return new ConnectorSettings();
        var encrypted = await File.ReadAllBytesAsync(_path, cancellationToken);
        var clear = ProtectedData.Unprotect(encrypted, Entropy, DataProtectionScope.LocalMachine);
        return JsonSerializer.Deserialize<ConnectorSettings>(clear, _json) ?? new ConnectorSettings();
    }

    public async Task SaveAsync(ConnectorSettings settings, CancellationToken cancellationToken)
    {
        var clear = JsonSerializer.SerializeToUtf8Bytes(settings, _json);
        var encrypted = ProtectedData.Protect(clear, Entropy, DataProtectionScope.LocalMachine);
        var temporary = _path + ".tmp";
        await File.WriteAllBytesAsync(temporary, encrypted, cancellationToken);
        File.Move(temporary, _path, true);
        CryptographicOperations.ZeroMemory(clear);
    }

    public Task ForgetAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (File.Exists(_path)) File.Delete(_path);
        return Task.CompletedTask;
    }
}
