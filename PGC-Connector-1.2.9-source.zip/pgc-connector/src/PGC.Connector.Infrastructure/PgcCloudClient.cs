using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using PGC.Connector.Core;

namespace PGC.Connector.Infrastructure;

public sealed class PgcCloudClient(HttpClient httpClient)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() }
    };
    private readonly HttpClient _http = httpClient;

    public async Task<PairResponse> PairAsync(Uri baseUrl, PairRequest request, CancellationToken cancellationToken)
    {
        using var message = new HttpRequestMessage(HttpMethod.Post, new Uri(baseUrl, "/api/integration/v1/pair"))
        {
            Content = JsonContent.Create(request, options: Json)
        };
        using var response = await _http.SendAsync(message, cancellationToken);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<PairResponse>(Json, cancellationToken)
            ?? throw new InvalidOperationException("پاسخ Pairing نامعتبر است.");
    }

    public async Task<IReadOnlyList<ConnectorCommand>> PullCommandsAsync(ConnectorSettings settings, CancellationToken cancellationToken)
    {
        using var response = await SendSignedAsync(settings, HttpMethod.Get, "/api/integration/v1/commands?limit=50", null, cancellationToken);
        response.EnsureSuccessStatusCode();
        var envelope = await response.Content.ReadFromJsonAsync<CommandsEnvelope>(Json, cancellationToken);
        return envelope?.Commands ?? [];
    }

    public async Task SendEventsAsync(ConnectorSettings settings, IReadOnlyList<OutboxEvent> events, CancellationToken cancellationToken)
    {
        var body = new { events = events.Select(item => new { item.Id, item.EventType, item.PayloadJson, item.CreatedAt }).ToArray() };
        using var response = await SendSignedAsync(settings, HttpMethod.Post, "/api/integration/v1/events/batch", body, cancellationToken);
        response.EnsureSuccessStatusCode();
    }

    public async Task SendHeartbeatAsync(ConnectorSettings settings, AdapterHealth adapter, AdapterCapabilities capabilities,
        QueueStatistics queue, string version, CancellationToken cancellationToken)
    {
        var body = new
        {
            version,
            machine = Environment.MachineName,
            os = Environment.OSVersion.VersionString,
            adapter,
            capabilities,
            queue,
            settings.AutoStartSessions,
            settings.AutoStopSessions
        };
        using var response = await SendSignedAsync(settings, HttpMethod.Post, "/api/integration/v1/heartbeat", body, cancellationToken);
        response.EnsureSuccessStatusCode();
    }

    public async Task ForgetAsync(ConnectorSettings settings, CancellationToken cancellationToken)
    {
        using var response = await SendSignedAsync(settings, HttpMethod.Post, "/api/integration/v1/forget", new { }, cancellationToken);
        response.EnsureSuccessStatusCode();
    }

    private async Task<HttpResponseMessage> SendSignedAsync(ConnectorSettings settings, HttpMethod method, string path, object? body, CancellationToken cancellationToken)
    {
        if (!settings.IsPaired) throw new InvalidOperationException("Connector هنوز Pair نشده است.");
        var rawBody = body is null ? Array.Empty<byte>() : JsonSerializer.SerializeToUtf8Bytes(body, Json);
        var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture);
        var nonce = Guid.NewGuid().ToString("N");
        var bodyHash = Convert.ToHexStringLower(SHA256.HashData(rawBody));
        var canonical = $"{method.Method.ToUpperInvariant()}\n{path}\n{timestamp}\n{nonce}\n{bodyHash}";
        using var signer = ECDsa.Create();
        signer.ImportFromPem(settings.PrivateKeyPem);
        var signature = signer.SignData(Encoding.UTF8.GetBytes(canonical), HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence);

        using var message = new HttpRequestMessage(method, new Uri(settings.PgcBaseUrl, path));
        if (rawBody.Length > 0) message.Content = new ByteArrayContent(rawBody) { Headers = { ContentType = new("application/json") } };
        message.Headers.Add("X-PGC-Connector-Id", settings.ConnectorId);
        message.Headers.Add("X-PGC-Timestamp", timestamp);
        message.Headers.Add("X-PGC-Nonce", nonce);
        message.Headers.Add("X-PGC-Content-SHA256", bodyHash);
        message.Headers.Add("X-PGC-Signature", Convert.ToBase64String(signature));
        return await _http.SendAsync(message, cancellationToken);
    }

    private sealed record CommandsEnvelope(IReadOnlyList<ConnectorCommand> Commands);
}
