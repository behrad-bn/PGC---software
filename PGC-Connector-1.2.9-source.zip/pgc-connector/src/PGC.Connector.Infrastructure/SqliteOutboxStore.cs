using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Data.Sqlite;
using PGC.Connector.Core;

namespace PGC.Connector.Infrastructure;

public sealed class SqliteOutboxStore(string dataDirectory) : IOutboxStore
{
    private readonly string _connectionString = new SqliteConnectionStringBuilder
    {
        DataSource = Path.Combine(dataDirectory, "connector.db"),
        Mode = SqliteOpenMode.ReadWriteCreate,
        Cache = SqliteCacheMode.Shared,
        Pooling = true
    }.ToString();
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() }
    };

    private SqliteConnection Open()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(new SqliteConnectionStringBuilder(_connectionString).DataSource)!);
        var connection = new SqliteConnection(_connectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText = "PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;";
        command.ExecuteNonQuery();
        return connection;
    }

    public async Task InitializeAsync(CancellationToken cancellationToken)
    {
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            CREATE TABLE IF NOT EXISTS incoming_commands(
              id TEXT PRIMARY KEY,
              idempotency_key TEXT NOT NULL UNIQUE,
              command_json TEXT NOT NULL,
              state TEXT NOT NULL DEFAULT 'Pending',
              attempts INTEGER NOT NULL DEFAULT 0,
              next_attempt_at TEXT NOT NULL,
              last_error TEXT,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_commands_ready ON incoming_commands(state,next_attempt_at);
            CREATE TABLE IF NOT EXISTS processed_commands(
              idempotency_key TEXT PRIMARY KEY,
              result_json TEXT NOT NULL,
              processed_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS outbox_events(
              id TEXT PRIMARY KEY,
              event_type TEXT NOT NULL,
              payload_json TEXT NOT NULL,
              attempts INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL,
              sent_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_events_pending ON outbox_events(sent_at,created_at);
            CREATE TABLE IF NOT EXISTS device_mappings(
              pgc_device_id TEXT NOT NULL,
              pgc_device_index INTEGER NOT NULL,
              external_device_id TEXT NOT NULL,
              external_device_name TEXT NOT NULL,
              device_type TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              PRIMARY KEY(pgc_device_id,pgc_device_index),
              UNIQUE(external_device_id)
            );
            """;
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<bool> IsProcessedAsync(string idempotencyKey, CancellationToken cancellationToken)
    {
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT 1 FROM processed_commands WHERE idempotency_key=$key LIMIT 1";
        command.Parameters.AddWithValue("$key", idempotencyKey);
        return await command.ExecuteScalarAsync(cancellationToken) is not null;
    }

    public async Task SaveIncomingAsync(ConnectorCommand commandValue, CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow.ToString("O");
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO incoming_commands(id,idempotency_key,command_json,state,attempts,next_attempt_at,created_at,updated_at)
            VALUES($id,$key,$json,'Pending',0,$next,$created,$created)
            ON CONFLICT(idempotency_key) DO NOTHING
            """;
        command.Parameters.AddWithValue("$id", commandValue.Id);
        command.Parameters.AddWithValue("$key", commandValue.IdempotencyKey);
        command.Parameters.AddWithValue("$json", JsonSerializer.Serialize(commandValue, Json));
        command.Parameters.AddWithValue("$next", now);
        command.Parameters.AddWithValue("$created", now);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<ConnectorCommand>> GetReadyAsync(int take, CancellationToken cancellationToken)
    {
        var result = new List<ConnectorCommand>();
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT command_json FROM incoming_commands
            WHERE state IN ('Pending','Failed') AND attempts < 10 AND next_attempt_at <= $now
            ORDER BY created_at LIMIT $take
            """;
        command.Parameters.AddWithValue("$now", DateTimeOffset.UtcNow.ToString("O"));
        command.Parameters.AddWithValue("$take", Math.Clamp(take, 1, 100));
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var value = JsonSerializer.Deserialize<ConnectorCommand>(reader.GetString(0), Json);
            if (value is not null) result.Add(value);
        }
        return result;
    }

    public async Task<CommandExecutionResult> MarkResultAsync(CommandExecutionResult result, string idempotencyKey, CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        await using var connection = Open();
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken);
        await using var attemptsCommand = connection.CreateCommand();
        attemptsCommand.Transaction = (SqliteTransaction)transaction;
        attemptsCommand.CommandText = "SELECT attempts FROM incoming_commands WHERE id=$id";
        attemptsCommand.Parameters.AddWithValue("$id", result.CommandId);
        var nextAttempt = Convert.ToInt32(await attemptsCommand.ExecuteScalarAsync(cancellationToken) ?? 0) + 1;
        var storedResult = result.State == CommandState.Failed && nextAttempt >= 10
            ? result with { State = CommandState.DeadLetter, Code = "retry-exhausted", Message = $"پس از ۱۰ تلاش ناموفق متوقف شد: {result.Message}" }
            : result;
        if (storedResult.State == CommandState.Succeeded)
        {
            await using var processed = connection.CreateCommand();
            processed.Transaction = (SqliteTransaction)transaction;
            processed.CommandText = "INSERT OR IGNORE INTO processed_commands(idempotency_key,result_json,processed_at) VALUES($key,$json,$at)";
            processed.Parameters.AddWithValue("$key", idempotencyKey);
            processed.Parameters.AddWithValue("$json", JsonSerializer.Serialize(storedResult, Json));
            processed.Parameters.AddWithValue("$at", now.ToString("O"));
            await processed.ExecuteNonQueryAsync(cancellationToken);
        }
        await using var update = connection.CreateCommand();
        update.Transaction = (SqliteTransaction)transaction;
        update.CommandText = """
            UPDATE incoming_commands
            SET state=$state, attempts=attempts+1, next_attempt_at=$next, last_error=$error, updated_at=$at
            WHERE id=$id
            """;
        update.Parameters.AddWithValue("$state", storedResult.State.ToString());
        var attemptsDelay = storedResult.State == CommandState.Succeeded
            ? TimeSpan.Zero
            : TimeSpan.FromSeconds(Math.Min(900, 15 * Math.Pow(2, Math.Min(6, nextAttempt - 1))));
        update.Parameters.AddWithValue("$next", now.Add(attemptsDelay).ToString("O"));
        update.Parameters.AddWithValue("$error", storedResult.SuccessMessage());
        update.Parameters.AddWithValue("$at", now.ToString("O"));
        update.Parameters.AddWithValue("$id", result.CommandId);
        await update.ExecuteNonQueryAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return storedResult;
    }

    public async Task EnqueueEventAsync(string eventType, object payload, CancellationToken cancellationToken)
    {
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = "INSERT INTO outbox_events(id,event_type,payload_json,created_at) VALUES($id,$type,$payload,$at)";
        command.Parameters.AddWithValue("$id", Guid.NewGuid().ToString("N"));
        command.Parameters.AddWithValue("$type", eventType);
        command.Parameters.AddWithValue("$payload", JsonSerializer.Serialize(payload, Json));
        command.Parameters.AddWithValue("$at", DateTimeOffset.UtcNow.ToString("O"));
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<OutboxEvent>> GetPendingEventsAsync(int take, CancellationToken cancellationToken)
    {
        var result = new List<OutboxEvent>();
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT id,event_type,payload_json,created_at,attempts FROM outbox_events WHERE sent_at IS NULL ORDER BY created_at LIMIT $take";
        command.Parameters.AddWithValue("$take", Math.Clamp(take, 1, 100));
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
            result.Add(new OutboxEvent(reader.GetString(0), reader.GetString(1), reader.GetString(2), DateTimeOffset.Parse(reader.GetString(3)), reader.GetInt32(4)));
        return result;
    }

    public async Task MarkEventsSentAsync(IEnumerable<string> ids, CancellationToken cancellationToken)
    {
        await using var connection = Open();
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken);
        foreach (var id in ids)
        {
            await using var command = connection.CreateCommand();
            command.Transaction = (SqliteTransaction)transaction;
            command.CommandText = "UPDATE outbox_events SET sent_at=$at,attempts=attempts+1 WHERE id=$id";
            command.Parameters.AddWithValue("$at", DateTimeOffset.UtcNow.ToString("O"));
            command.Parameters.AddWithValue("$id", id);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        await transaction.CommitAsync(cancellationToken);
        await using var cleanup = connection.CreateCommand();
        cleanup.CommandText = """
            DELETE FROM outbox_events WHERE sent_at IS NOT NULL AND sent_at < $events;
            DELETE FROM incoming_commands WHERE state='Succeeded' AND updated_at < $commands;
            DELETE FROM processed_commands WHERE processed_at < $processed;
            """;
        cleanup.Parameters.AddWithValue("$events", DateTimeOffset.UtcNow.AddDays(-30).ToString("O"));
        cleanup.Parameters.AddWithValue("$commands", DateTimeOffset.UtcNow.AddDays(-30).ToString("O"));
        cleanup.Parameters.AddWithValue("$processed", DateTimeOffset.UtcNow.AddDays(-180).ToString("O"));
        await cleanup.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task UpsertMappingsAsync(IEnumerable<DeviceMapping> mappings, CancellationToken cancellationToken)
    {
        await using var connection = Open();
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken);
        foreach (var mapping in mappings)
        {
            await using var command = connection.CreateCommand();
            command.Transaction = (SqliteTransaction)transaction;
            command.CommandText = """
                INSERT INTO device_mappings(pgc_device_id,pgc_device_index,external_device_id,external_device_name,device_type,updated_at)
                VALUES($pgc,$idx,$external,$name,$type,$at)
                ON CONFLICT(pgc_device_id,pgc_device_index) DO UPDATE SET
                  external_device_id=excluded.external_device_id,external_device_name=excluded.external_device_name,
                  device_type=excluded.device_type,updated_at=excluded.updated_at
                """;
            command.Parameters.AddWithValue("$pgc", mapping.PgcDeviceId);
            command.Parameters.AddWithValue("$idx", mapping.PgcDeviceIndex);
            command.Parameters.AddWithValue("$external", mapping.ExternalDeviceId);
            command.Parameters.AddWithValue("$name", mapping.ExternalDeviceName);
            command.Parameters.AddWithValue("$type", mapping.DeviceType);
            command.Parameters.AddWithValue("$at", mapping.UpdatedAt.ToString("O"));
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        await transaction.CommitAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<DeviceMapping>> GetMappingsAsync(CancellationToken cancellationToken)
    {
        var result = new List<DeviceMapping>();
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT pgc_device_id,pgc_device_index,external_device_id,external_device_name,device_type,updated_at FROM device_mappings ORDER BY pgc_device_id,pgc_device_index";
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
            result.Add(new DeviceMapping(reader.GetString(0), reader.GetInt32(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), DateTimeOffset.Parse(reader.GetString(5))));
        return result;
    }

    public async Task<QueueStatistics> GetStatisticsAsync(CancellationToken cancellationToken)
    {
        await using var connection = Open();
        async Task<int> CountAsync(string sql)
        {
            await using var command = connection.CreateCommand();
            command.CommandText = sql;
            return Convert.ToInt32(await command.ExecuteScalarAsync(cancellationToken));
        }
        return new QueueStatistics(
            await CountAsync("SELECT COUNT(*) FROM incoming_commands WHERE state IN ('Pending','Failed')"),
            await CountAsync("SELECT COUNT(*) FROM incoming_commands WHERE state IN ('Failed','DeadLetter','Conflict')"),
            await CountAsync("SELECT COUNT(*) FROM outbox_events WHERE sent_at IS NULL"),
            null);
    }

    public async Task ClearPairingDataAsync(CancellationToken cancellationToken)
    {
        await using var connection = Open();
        await using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM incoming_commands; DELETE FROM processed_commands; DELETE FROM outbox_events; DELETE FROM device_mappings;";
        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}

internal static class ResultExtensions
{
    public static string SuccessMessage(this CommandExecutionResult result) => result.State == CommandState.Succeeded ? string.Empty : $"{result.Code}: {result.Message}";
}
