﻿#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  try {
    $arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $PSCommandPath
    $elevated = Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -Verb RunAs -PassThru -Wait
    exit $elevated.ExitCode
  }
  catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show('برای نصب PGC Connector دسترسی Administrator لازم است.', 'PGC Connector Setup') | Out-Null
    exit 1223
  }
}

$logDirectory = Join-Path $env:ProgramData 'PGC\Connector\setup-logs'
New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
$logPath = Join-Path $logDirectory 'setup.log'
Start-Transcript -Path $logPath -Append | Out-Null
try {
  & (Join-Path $PSScriptRoot 'install.ps1')
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show('PGC Connector نصب و سرویس فعال شد. از منوی Start آن را اجرا کنید.', 'PGC Connector Setup') | Out-Null
  exit 0
}
catch {
  Write-Host $_.Exception.Message -ForegroundColor Red
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(("نصب کامل نشد: {0}`nلاگ: {1}" -f $_.Exception.Message, $logPath), 'PGC Connector Setup') | Out-Null
  exit 1
}
finally { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
