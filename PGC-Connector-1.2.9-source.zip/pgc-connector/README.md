# PGC Connector 1.2.9 (source)

برنامه ویندوزی آفلاین‌محور برای اتصال PGC به نرم‌افزار مدیریت داخلی گیم‌نت. راهکار از دو پردازش جدا تشکیل شده است:

- `PGC.Connector.Service`: سرویس Windows با شروع خودکار، همگام‌سازی، صف SQLite و اجرای فرمان‌ها.
- `PGC.Connector.Desktop`: رابط فارسی RTL با Tray icon، منوی همبرگری انیمیشنی، معرفی برنامه، آموزش تصویری، Pairing، تنظیم Adapter، مشاهده وضعیت، دستگاه‌ها و گزارش‌ها.

## تغییرات رابط نسخه 1.1

- حذف TabControl قبلی و رفع قطعی باگ محوشدن/بریده‌شدن عنوان منوها.
- نمایش عنوان هر بخش در هدر ثابت و انتقال همه مسیرها به منوی همبرگری RTL.
- استفاده از تصویر پس‌زمینه وب‌سایت PGC، لوگوی رسمی ارسالی و فونت داخلی Vazirmatn.
- صفحه خانه برای معرفی Connector و صفحه آموزش تصویری سه‌مرحله‌ای.
- ساخت Shortcut در Desktop و Start Menu و ثبت App Paths؛ پس از نصب، عبارت `PGC Connector` در Windows Search برنامه را پیدا می‌کند.

## معماری اتصال

چهار نرم‌افزار اصلی ggLeap، Smartlaunch، Launch Desk و Game Manager مطابق تصمیم معماری از طریق Backend وب‌سایت PGC و فقط پس از دریافت قرارداد/API واقعی فروشندگان متصل می‌شوند. این بستهٔ Windows برای نرم‌افزارهای **متفرقه** با API محلی یا SDK Bridge است. اگر نرم‌افزار هیچ رابط رسمی نداشته باشد، مسیر درست ثبت ظرفیت و رزرو دستی است. جدول دقیق و قرارداد SDK Bridge در `docs/INTEGRATION_ARCHITECTURE_2026-09-23.md` آمده است.

## وضعیت اتصال Vendorها در این سورس

| Vendor | وضعیت | قابلیت‌های فعال |
|---|---|---|
| چهار نرم‌افزار اصلی | انتخاب در Connector غیرفعال؛ Cloud Backend نیازمند قرارداد رسمی | اتصال واقعی هنوز برقرار نشده است |
| REST نرم‌افزار متفرقه | چارچوب محلی آماده | endpoint، توکن و آزمایش Vendor لازم است |
| SDK نرم‌افزار متفرقه | قرارداد Bridge جداگانه آماده | کد SDK هر Vendor باید جداگانه و مجاز تولید شود |
| Simulator | در سرویس عملیاتی غیرفعال | دادهٔ ساختگی وارد ظرفیت نمی‌شود |

کد REST محلی قدیمی Smartlaunch برای مطالعه نگه داشته شده، اما در تنظیمات عملیاتی Connector قابل انتخاب نیست. Cloud/OAuth هیچ‌یک از چهار Vendor بدون قرارداد و endpoint رسمی فعال نشده است.

## نصب خودکار از سورس

PowerShell را با **Run as administrator** اجرا کنید، وارد پوشه استخراج‌شده شوید و فقط دستور زیر را بزنید:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\scripts\setup.ps1
```

`setup.ps1` وجود .NET 10 SDK را بررسی می‌کند، در صورت امکان آن را با winget نصب می‌کند، Restore/Build/Test/Publish را انجام می‌دهد، Windows Service را نصب می‌کند و Shortcut قابل جست‌وجو می‌سازد.

## ساخت خروجی Windows بدون نصب

نیازمندی: Windows 10/11 x64 و `.NET 10 SDK`.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\build-release.ps1
```

خروجی self-contained در `artifacts` ساخته می‌شود؛ سیستم مقصد به نصب .NET نیاز ندارد.

نصب‌کنندهٔ جدید در `artifacts\installer\PGC-Connector-Setup-1.2.9-x64.exe` ساخته می‌شود. با دوبار کلیک آن را اجرا کنید؛ خودش UAC درخواست می‌کند و به SDK یا اجرای دستور در سیستم مقصد نیاز ندارد. پیش از نصب روی سیستم دیگری، SHA-256 فایل دانلودشده را با فایل checksum همین نسخه مقایسه کنید. این EXE هنوز امضای کد تجاری ندارد، پس Windows ممکن است هشدار SmartScreen نشان دهد.

Service با Startup خودکار و سیاست restart نصب می‌شود. رابط Desktop از Shortcut عمومی اجرا می‌شود و بستن پنجره آن را به Tray می‌فرستد. برای عیب‌یابی:

```powershell
.\diagnostics.ps1
```

## مسیر داده

`%ProgramData%\PGC\Connector`

- `connector.db`: فرمان‌ها و رویدادهای آفلاین در SQLite/WAL.
- `settings.bin`: تنظیمات و کلید خصوصی رمز‌شده با Windows DPAPI (LocalMachine).
- `local-admin-token.txt`: توکن رابط محلی.
- `logs`: Audit log روزانه JSONL.

ACL پوشه برای `SYSTEM` و گروه `Administrators` دسترسی کامل و برای حسابی که نصب را انجام داده دسترسی خواندن دارد. توکن محلی فقط برای همان حساب، `SYSTEM` و مدیران سیستم قابل خواندن است. API رابط فقط روی `127.0.0.1:47831` گوش می‌دهد و به توکن محلی نیاز دارد.

## منابع Vendor

- LaunchDesk: https://launchdesk.ir/
- Smartlaunch ایران: https://smartlaunch.ir/
- Smartlaunch REST API: https://smartlaunch.blob.core.windows.net/slpublic/Smartlaunch%20RESTful%20API%20Documentation%20NEW%20140714B.pdf
- ggLeap: https://www.ggcircuit.com/ggleap

## محدودیت تأیید

وضعیت تأیید و آزمون‌های لازم پیش از انتشار در `RELEASE-STATUS.md` ثبت شده است. این سورس در محیط ویندوزی فعلی ساخته و نصب نشده و فایل EXE تأییدشده از آن تحویل داده نمی‌شود.
