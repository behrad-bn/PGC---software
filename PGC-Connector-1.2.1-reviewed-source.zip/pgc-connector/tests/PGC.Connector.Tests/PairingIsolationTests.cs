using System.Text.Json;
using PGC.Connector.Core;
using PGC.Connector.Infrastructure;
using Xunit;

namespace PGC.Connector.Tests;

public sealed class PairingIsolationTests
{
    [Fact]
    public async Task ForgetRemovesOldVenueQueueAndMappings()
    {
        var directory = Path.Combine(Path.GetTempPath(), "pgc-isolation-" + Guid.NewGuid().ToString("N"));
        try
        {
            var store = new SqliteOutboxStore(directory);
            await store.InitializeAsync(default);
            await store.SaveIncomingAsync(new ConnectorCommand("cmd", "key", CommandKind.RefreshInventory, "venue-A",
                "reservation", DateTimeOffset.UtcNow, null, null, JsonDocument.Parse("{}").RootElement.Clone()), default);
            await store.EnqueueEventAsync("devices.snapshot", new { venue = "venue-A" }, default);
            await store.UpsertMappingsAsync([new DeviceMapping("pc", 1, "external-pc", "PC", "PC", DateTimeOffset.UtcNow)], default);

            await store.ClearPairingDataAsync(default);

            Assert.Empty(await store.GetReadyAsync(10, default));
            Assert.Empty(await store.GetPendingEventsAsync(10, default));
            Assert.Empty(await store.GetMappingsAsync(default));
        }
        finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
    }
}
