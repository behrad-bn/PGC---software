#Requires -Version 5.1
#Requires -RunAsAdministrator

$ErrorActionPreference = 'Stop'
$source = $PSScriptRoot
$target = Join-Path $env:ProgramFiles 'PGC Connector'
$serviceName = 'PGCConnector'
$operatorSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$dataDirectory = Join-Path $env:ProgramData 'PGC\Connector'
foreach ($path in @((Join-Path $env:ProgramData 'PGC'), $dataDirectory, (Join-Path $dataDirectory 'owner-sid.txt'))) {
  if (Test-Path -LiteralPath $path) {
    $entry = Get-Item -LiteralPath $path -Force
    if ($entry.Attributes -band [System.IO.FileAttributes]::ReparsePoint) {
      throw "Unsafe reparse point in installation data path: $path"
    }
  }
}
New-Item -ItemType Directory -Force $dataDirectory | Out-Null
$directoryAcl = New-Object System.Security.AccessControl.DirectorySecurity
$directoryAcl.SetAccessRuleProtection($true, $false)
$inherit = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
foreach ($sid in @('S-1-5-18', 'S-1-5-32-544')) {
  $identifier = [System.Security.Principal.SecurityIdentifier]::new($sid)
  $rule = [System.Security.AccessControl.FileSystemAccessRule]::new($identifier,
    [System.Security.AccessControl.FileSystemRights]::FullControl, $inherit,
    [System.Security.AccessControl.PropagationFlags]::None,
    [System.Security.AccessControl.AccessControlType]::Allow)
  $directoryAcl.AddAccessRule($rule)
}
Set-Acl -LiteralPath $dataDirectory -AclObject $directoryAcl
$ownerFile = Join-Path $dataDirectory 'owner-sid.txt'
Set-Content -LiteralPath $ownerFile -Value $operatorSid -Encoding Ascii
$ownerAcl = New-Object System.Security.AccessControl.FileSecurity
$ownerAcl.SetAccessRuleProtection($true, $false)
foreach ($sid in @('S-1-5-18', 'S-1-5-32-544')) {
  $rule = [System.Security.AccessControl.FileSystemAccessRule]::new(
    [System.Security.Principal.SecurityIdentifier]::new($sid),
    [System.Security.AccessControl.FileSystemRights]::FullControl,
    [System.Security.AccessControl.AccessControlType]::Allow)
  $ownerAcl.AddAccessRule($rule)
}
Set-Acl -LiteralPath $ownerFile -AclObject $ownerAcl
$serviceSource = Join-Path $source 'service\PGC.Connector.Service.exe'
$desktopSource = Join-Path $source 'desktop\PGC.Connector.Desktop.exe'

if (-not (Test-Path $serviceSource) -or -not (Test-Path $desktopSource)) {
  throw 'install.ps1 باید از پوشه artifacts منتشرشده اجرا شود.'
}

if (Get-Service $serviceName -ErrorAction SilentlyContinue) {
  Stop-Service $serviceName -Force -ErrorAction SilentlyContinue
  & sc.exe delete $serviceName | Out-Null
  for ($attempt = 0; $attempt -lt 30; $attempt++) {
    if (-not (Get-Service $serviceName -ErrorAction SilentlyContinue)) { break }
    Start-Sleep -Seconds 1
  }
  if (Get-Service $serviceName -ErrorAction SilentlyContinue) {
    throw 'سرویس قدیمی هنوز در حال حذف شدن است؛ Windows را Restart کنید و نصب را دوباره اجرا کنید.'
  }
}
Get-Process 'PGC.Connector.Desktop' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 500

New-Item -ItemType Directory -Force $target | Out-Null
New-Item -ItemType Directory -Force (Join-Path $target 'service') | Out-Null
New-Item -ItemType Directory -Force (Join-Path $target 'desktop') | Out-Null
Copy-Item (Join-Path $source 'service\*') (Join-Path $target 'service') -Recurse -Force
Copy-Item (Join-Path $source 'desktop\*') (Join-Path $target 'desktop') -Recurse -Force
Copy-Item (Join-Path $source 'uninstall.ps1') $target -Force
Copy-Item (Join-Path $source 'diagnostics.ps1') $target -Force

$serviceExe = Join-Path $target 'service\PGC.Connector.Service.exe'
$desktopExe = Join-Path $target 'desktop\PGC.Connector.Desktop.exe'
& sc.exe create $serviceName binPath= "`"$serviceExe`"" start= auto DisplayName= 'PGC Connector' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'ثبت Windows Service ناموفق بود.' }
& sc.exe description $serviceName 'Secure offline-first bridge between PGC and gaming-center management software.' | Out-Null
& sc.exe failure $serviceName reset= 86400 actions= restart/5000/restart/15000/restart/60000 | Out-Null
& sc.exe failureflag $serviceName 1 | Out-Null
& sc.exe config $serviceName start= delayed-auto | Out-Null
Start-Service $serviceName
$serviceReady = $false
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  try {
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:47831/local/health' -TimeoutSec 2
    if ($health.ok -eq $true) { $serviceReady = $true; break }
  }
  catch { Start-Sleep -Seconds 1 }
}
if (-not $serviceReady) {
  throw 'سرویس نصب شد اما API محلی طی ۳۰ ثانیه آماده نشد. diagnostics.ps1 را اجرا کنید.'
}

function New-PgcShortcut([string]$Path) {
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($Path)
  $shortcut.TargetPath = $desktopExe
  $shortcut.WorkingDirectory = Split-Path $desktopExe
  $shortcut.IconLocation = "$desktopExe,0"
  $shortcut.Description = 'PGC Connector'
  $shortcut.Save()
}

$publicDesktop = Join-Path $env:Public 'Desktop\PGC Connector.lnk'
New-PgcShortcut $publicDesktop

$startMenuDirectory = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\PGC Connector'
New-Item -ItemType Directory -Force $startMenuDirectory | Out-Null
New-PgcShortcut (Join-Path $startMenuDirectory 'PGC Connector.lnk')

$appPathKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\PGC Connector.exe'
New-Item -Path $appPathKey -Force | Out-Null
Set-Item -Path $appPathKey -Value $desktopExe
New-ItemProperty -Path $appPathKey -Name 'Path' -Value (Split-Path $desktopExe) -PropertyType String -Force | Out-Null

$uninstallKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PGC Connector'
New-Item -Path $uninstallKey -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'DisplayName' -Value 'PGC Connector' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'DisplayVersion' -Value '1.2.1' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'Publisher' -Value 'Persian Gaming Center' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'DisplayIcon' -Value "$desktopExe,0" -PropertyType String -Force | Out-Null
$uninstallCommand = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $target 'uninstall.ps1')`""
New-ItemProperty -Path $uninstallKey -Name 'UninstallString' -Value $uninstallCommand -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'NoModify' -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'NoRepair' -Value 1 -PropertyType DWord -Force | Out-Null

Write-Host 'PGC Connector installed. Open it from Windows Search as the installing user.' -ForegroundColor Green
