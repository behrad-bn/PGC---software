using System.Security.Cryptography;
using System.Text;
using System.Net;
using System.Text.Json.Serialization;
using PGC.Connector.Core;
using PGC.Connector.Infrastructure;
using PGC.Connector.Service;

ConnectorPaths.EnsureSecureDirectory();
var builder = WebApplication.CreateBuilder(args);
builder.Host.UseWindowsService(options => options.ServiceName = "PGC Connector");
builder.WebHost.UseUrls("http://127.0.0.1:47831");
builder.Services.AddHttpClient("pgc-cloud", client => client.Timeout = TimeSpan.FromSeconds(20))
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler { AllowAutoRedirect = false });
builder.Services.AddHttpClient("vendor", client => client.Timeout = TimeSpan.FromSeconds(15))
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler { AllowAutoRedirect = false, UseProxy = false });
builder.Services.AddSingleton<ISecureSettingsStore>(_ => new SecureSettingsStore(ConnectorPaths.DataDirectory));
builder.Services.AddSingleton<IOutboxStore>(_ => new SqliteOutboxStore(ConnectorPaths.DataDirectory));
builder.Services.AddSingleton<ConnectorAuditLog>();
builder.Services.AddSingleton<LocalAdminToken>();
builder.Services.AddSingleton<ConnectorRuntime>();
builder.Services.AddHostedService(provider => provider.GetRequiredService<ConnectorRuntime>());
builder.Services.ConfigureHttpJsonOptions(options =>
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));

var app = builder.Build();
app.Use(async (context, next) =>
{
    if (!IPAddress.IsLoopback(context.Connection.RemoteIpAddress ?? IPAddress.None))
    {
        context.Response.StatusCode = StatusCodes.Status403Forbidden;
        return;
    }
    context.Response.Headers.CacheControl = "no-store";
    if (!context.Request.Path.StartsWithSegments("/local/health"))
    {
        var expected = app.Services.GetRequiredService<LocalAdminToken>().Value;
        var supplied = context.Request.Headers["X-PGC-Local-Token"].ToString();
        var x = Encoding.UTF8.GetBytes(expected);
        var y = Encoding.UTF8.GetBytes(supplied);
        if (x.Length != y.Length || !CryptographicOperations.FixedTimeEquals(x, y))
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return;
        }
    }
    await next();
});

app.MapGet("/local/health", () => Results.Json(new { ok = true, serviceName = "PGC Connector" }));
app.MapGet("/local/status", async (ConnectorRuntime runtime, CancellationToken ct) => Results.Json(new
{
    runtime.Version,
    paired = runtime.Settings.IsPaired,
    runtime.Settings.GamenetId,
    runtime.Settings.GamenetName,
    runtime.Settings.Vendor,
    adapter = runtime.LastAdapterHealth,
    runtime.LastCloudSuccessAt,
    queue = await runtime.GetQueueStatisticsAsync(ct)
}));
app.MapGet("/local/config", (ConnectorRuntime runtime) => Results.Json(new
{
    runtime.Settings.PgcBaseUrl,
    runtime.Settings.GamenetId,
    runtime.Settings.GamenetName,
    runtime.Settings.Vendor,
    runtime.Settings.VendorBaseUrl,
    hasVendorApiToken = !string.IsNullOrWhiteSpace(runtime.Settings.VendorApiToken),
    runtime.Settings.VendorOptionsJson,
    runtime.Settings.AutoStartSessions,
    runtime.Settings.AutoStopSessions,
    runtime.Settings.PollSeconds
}));
app.MapPost("/local/pair", async (PairLocalRequest request, ConnectorRuntime runtime, CancellationToken ct) =>
{
    var result = await runtime.PairAsync(request.PgcBaseUrl, request.PairCode, request.ConnectorName, ct);
    return Results.Json(result);
});
app.MapPost("/local/settings", async (SettingsUpdate request, ConnectorRuntime runtime, CancellationToken ct) =>
{
    await runtime.UpdateSettingsAsync(request, ct);
    return Results.Ok();
});
app.MapPost("/local/forget", async (ConnectorRuntime runtime, CancellationToken ct) =>
{
    await runtime.ForgetAsync(ct);
    return Results.Ok();
});
app.MapGet("/local/devices", async (ConnectorRuntime runtime, CancellationToken ct) => Results.Json(await runtime.GetDevicesAsync(ct)));
app.MapGet("/local/mappings", async (ConnectorRuntime runtime, CancellationToken ct) => Results.Json(await runtime.GetMappingsAsync(ct)));
app.MapPut("/local/mappings", async (DeviceMapping[] mappings, ConnectorRuntime runtime, CancellationToken ct) =>
{
    await runtime.SaveMappingsAsync(mappings, ct);
    return Results.Ok();
});
app.MapGet("/local/logs", async (int? take, ConnectorRuntime runtime, CancellationToken ct) => Results.Json(await runtime.GetLogsAsync(take ?? 100, ct)));

await app.RunAsync();

public sealed record PairLocalRequest(Uri PgcBaseUrl, string PairCode, string ConnectorName);
